<?php
/**
 * ============================================================================
 * WeaveCMS – Release Packaging Generator (tools/build_release.php)
 * ============================================================================
 * Erzeugt distributionsfertige Release-Pakete:
 * - Typ 'full': Voll-Paket (weavecms-vX.Y.Z.zip) für Neuinstallationen
 * - Typ 'update': Update-Paket (update-vX.Y.Z.zip) für bestehende Websites
 * - Typ 'all': Erstellt beide Pakete nacheinander (Standard)
 * 
 * Synchronisiert automatisch:
 * - README.md (Versionsnummer, Download-Links, exakte Dateigrößen)
 * ============================================================================
 */

if (php_sapi_name() !== 'cli' && empty($_SESSION['admin_logged_in'])) {
    die("Zugriff verweigert: Bitte über die CLI oder als angemeldeter Administrator ausführen.\n");
}

$root = dirname(__DIR__);
require_once $root . '/config.php';

$version = defined('WEAVE_VERSION') ? WEAVE_VERSION : '1.0.0';
$targetType = $argv[1] ?? ($_GET['type'] ?? 'all'); // 'all', 'full', 'update'

if (!class_exists('ZipArchive')) {
    die("Fehler: PHP-Erweiterung 'zip' (ZipArchive) ist nicht aktiviert.\n");
}

$outputDir = $root . '/releases';
if (!is_dir($outputDir)) {
    @mkdir($outputDir, 0755, true);
}

/**
 * Erstellt ein Release-ZIP-Archiv (Typ 'full' oder 'update').
 */
function buildReleaseZip(string $root, string $version, string $buildType): array {
    $outputDir = $root . '/releases';
    $zip = new ZipArchive();
    $filename = ($buildType === 'update') 
        ? "update-v{$version}.zip" 
        : "weavecms-v{$version}.zip";
    $zipPath = $outputDir . '/' . $filename;

    if (file_exists($zipPath)) {
        @unlink($zipPath);
    }

    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new RuntimeException("Fehler beim Erstellen der ZIP-Datei: {$zipPath}");
    }

    // Ausschluss-Muster (Reguläre Ausdrücke)
    $excludePatterns = [
        '~^\.git~',
        '~^\.agents~',
        '~^\.system_generated~',
        '~^releases~',
        '~^backups~',
        '~^logs/.*\.log$~',
        '~^cache/.*~',
        '~^scratch/.*~',
        '~^installed\.lock$~',
        '~^config\.local\.php$~',
        '~^data\.json$~',
        '~^contacts\.json$~',
        '~^data/sandbox/.*~',
        '~^data/stats\.json$~',
        '~^data/.*\.sqlite$~',
        '~^images/uploads/(?!(\.gitkeep|\.htaccess)$).*~',
        '~^downloads/(?!(\.gitkeep|\.htaccess)$).*~'
    ];

    // Für Update-Pakete werden ausschließlich Kern-Dateien aufgenommen
    $updateAllowedRoots = [
        'admin',
        'libs',
        'views',
        'plugins',
        'api',
        'index.php',
        'config.php',
        'send_mail.php',
        'sitemap.php',
        'robots.php',
        '.htaccess'
    ];

    $fileCount = 0;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        $filePath = str_replace('\\', '/', $item->getPathname());
        $relPath = ltrim(substr($filePath, strlen(str_replace('\\', '/', $root))), '/');

        if (empty($relPath)) {
            continue;
        }

        // Ausschluss-Filter prüfen
        $excluded = false;
        foreach ($excludePatterns as $pattern) {
            if (preg_match($pattern, $relPath)) {
                $excluded = true;
                break;
            }
        }
        if ($excluded) {
            continue;
        }

        // Update-Paket Filterung
        if ($buildType === 'update') {
            $allowed = false;
            foreach ($updateAllowedRoots as $prefix) {
                if ($relPath === $prefix || str_starts_with($relPath, $prefix . '/')) {
                    $allowed = true;
                    break;
                }
            }
            if (!$allowed) {
                continue;
            }
        }

        if ($item->isDir()) {
            $zip->addEmptyDir($relPath);
        } elseif ($item->isFile()) {
            $zip->addFile($item->getPathname(), $relPath);
            $fileCount++;
        }
    }

    $zip->close();
    $sizeMb = round(filesize($zipPath) / (1024 * 1024), 2);
    $sha256 = hash_file('sha256', $zipPath);

    return [
        'type' => $buildType,
        'filename' => $filename,
        'path' => $zipPath,
        'files' => $fileCount,
        'sizeMb' => $sizeMb,
        'sha256' => $sha256
    ];
}

/**
 * Synchronisiert die Versionsangaben und Dateigrößen automatisch mit der README.md.
 */
function syncReadmeVersion(string $root, string $version, array $hashes = []): array {
    $readmePath = $root . '/README.md';
    if (!file_exists($readmePath)) {
        return ['success' => false, 'error' => 'README.md nicht gefunden'];
    }

    $content = file_get_contents($readmePath);
    if ($content === false) {
        return ['success' => false, 'error' => 'README.md konnte nicht gelesen werden'];
    }

    $outputDir = $root . '/releases';
    $fullZip = $outputDir . "/weavecms-v{$version}.zip";
    $updateZip = $outputDir . "/update-v{$version}.zip";

    $fullMb = file_exists($fullZip) ? round(filesize($fullZip) / (1024 * 1024), 2) : null;
    $updateMb = file_exists($updateZip) ? round(filesize($updateZip) / (1024 * 1024), 2) : null;
    $fullSha = $hashes['full'] ?? (file_exists($fullZip) ? hash_file('sha256', $fullZip) : '');
    $updateSha = $hashes['update'] ?? (file_exists($updateZip) ? hash_file('sha256', $updateZip) : '');

    // 1. Überschrift: ## Releases & Downloads (vX.Y.Z)
    $content = preg_replace(
        '/^## Releases & Downloads \(v[^)]+\)/m',
        "## Releases & Downloads (v{$version})",
        $content
    );

    // 2. Full Package Download-Link & Größe
    $content = preg_replace(
        '/^-\s*📦\s*\*\*\[WeaveCMS\s+v[^\s\]]+\s+Full\s+Package\].*$/m',
        "- 📦 **[WeaveCMS v{$version} Full Package](releases/weavecms-v{$version}.zip)** (`releases/weavecms-v{$version}.zip`, {$fullMb} MB) – Complete installation archive for new websites.",
        $content
    );

    // 3. Update Package Download-Link & Größe
    $content = preg_replace(
        '/^-\s*🔄\s*\*\*\[WeaveCMS\s+v[^\s\]]+\s+Update\s+Package\].*$/m',
        "- 🔄 **[WeaveCMS v{$version} Update Package](releases/update-v{$version}.zip)** (`releases/update-v{$version}.zip`, {$updateMb} MB) – Core system files for upgrading existing installations.",
        $content
    );

    // 4. Download-Link im Installations-Abschnitt
    $content = preg_replace(
        '/Download \*\*\[weavecms-v[^\]]+\.zip\]\([^)]+\)\*\*/i',
        "Download **[weavecms-v{$version}.zip](releases/weavecms-v{$version}.zip)**",
        $content
    );

    file_put_contents($readmePath, $content);

    return [
        'success' => true,
        'version' => $version,
        'fullMb' => $fullMb,
        'updateMb' => $updateMb,
        'fullSha' => $fullSha,
        'updateSha' => $updateSha
    ];
}

/**
 * Aktualisiert version.json
 */
function syncVersionJson(string $root, string $version, ?string $updateSha256): void {
    $versionJsonPath = $root . '/version.json';
    $data = [
        'latest_version' => $version,
        'download_url' => "https://github.com/Vulfharban/WeaveCMS/releases/tag/v{$version}",
        'update_download_url' => "https://github.com/Vulfharban/WeaveCMS/releases/download/v{$version}/update-v{$version}.zip",
        'changelog' => "WeaveCMS v{$version} – Autonomes 3rd-Party Plugin-Update-System via GitHub Releases & CoreUpdater Pfad-Fix",
        'update_sha256' => $updateSha256 ? "update: {$updateSha256}" : ""
    ];
    file_put_contents($versionJsonPath, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n");
}

// Ausführung je nach Zieltyp
$typesToBuild = ($targetType === 'all') ? ['full', 'update'] : [$targetType];
$results = [];
$hashes = [];

echo "========================================================\n";
echo "WeaveCMS Release Packaging (v{$version})\n";
echo "========================================================\n";

foreach ($typesToBuild as $type) {
    $res = buildReleaseZip($root, $version, $type);
    $results[] = $res;
    $hashes[$type] = $res['sha256'];
    echo "✓ Paket (" . strtoupper($res['type']) . "): {$res['filename']}\n";
    echo "  Dateien: {$res['files']} | Größe: {$res['sizeMb']} MB\n";
    echo "  SHA-256: {$res['sha256']}\n";
}

// README automatisch synchronisieren
$sync = syncReadmeVersion($root, $version, $hashes);
if ($sync['success']) {
    echo "--------------------------------------------------------\n";
    echo "✓ README.md automatisch auf v{$version} synchronisiert!\n";
    if ($sync['fullMb'] !== null) {
        echo "  - Full Package:   {$sync['fullMb']} MB (SHA256: {$sync['fullSha']})\n";
    }
    if ($sync['updateMb'] !== null) {
        echo "  - Update Package: {$sync['updateMb']} MB (SHA256: {$sync['updateSha']})\n";
    }
} else {
    echo "! Warnung: README.md Synchronisation fehlgeschlagen ({$sync['error']})\n";
}

// version.json synchronisieren
syncVersionJson($root, $version, $hashes['update'] ?? ($sync['updateSha'] ?? null));
echo "✓ version.json automatisch aktualisiert!\n";

echo "========================================================\n";
