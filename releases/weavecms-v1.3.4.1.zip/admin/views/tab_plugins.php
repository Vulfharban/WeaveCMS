<?php
/**
 * WeaveCMS – Admin Tab: Plugins & Module (Phase 13)
 * 
 * @var array $data Gesamtdatenstruktur
 * @var string $csrf_token CSRF-Token
 */

$all_plugins = PluginManager::getAllPlugins($data);
$active_settings_slug = $_GET['plugin_settings'] ?? $_POST['plugin_slug'] ?? $_POST['plugin_settings'] ?? null;
?>
<!-- ──────────────── SECTION: PLUGINS & ERWEITERUNGEN ──────────────── -->
<div id="tab-plugins" class="admin-section card" style="padding: 2.5rem;">
    <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap: 1rem; margin-bottom: 2rem;">
        <div>
            <h2 style="color: var(--primary); margin:0 0 0.5rem 0; display:flex; align-items:center; gap: 10px;">
                <span class="material-icons" style="font-size:32px;">extension</span> <?php echo __a('admin.plugins.title', 'Modul- & Plugin-System'); ?>
            </h2>
            <p style="color: var(--text-secondary); margin:0; font-size: 0.95rem;">
                <?php echo __a('admin.plugins.subtitle', 'Erweitere WeaveCMS modular um zusätzliche Funktionen, Drittanbieter-Anbindungen (wie Webtrees Stammbäume) und Inhaltstypen.'); ?>
            </p>
        </div>
        <div style="display:flex; align-items:center; gap:8px;">
            <a href="?tab=tab-plugins&check_updates=1" class="btn btn-outline" style="padding: 6px 12px; font-size: 0.8rem; display:inline-flex; align-items:center; gap:5px;" title="<?php echo htmlspecialchars(__a('admin.plugins.btn_check_all_updates', 'Alle Plugins auf Updates prüfen')); ?>">
                <span class="material-icons" style="font-size:15px;">sync</span> <?php echo __a('admin.plugins.btn_check_all_updates', 'Updates prüfen'); ?>
            </a>
            <span style="background: rgba(46,98,72,0.1); color: var(--primary); font-size: 0.85rem; font-weight: 700; padding: 6px 14px; border-radius: 20px; border: 1px solid rgba(46,98,72,0.2);">
                <?php 
                    $active_count = count(array_filter($all_plugins, fn($p) => !empty($p['active'])));
                    echo __a('admin.plugins.badge_active', '{active} von {total} Plugins aktiv', null, ['active' => $active_count, 'total' => count($all_plugins)]);
                ?>
            </span>
        </div>
    </div>

    <?php 
    $missing_official = class_exists('PluginManager') ? PluginManager::getMissingOfficialPlugins() : [];
    if (!empty($missing_official)): 
    ?>
        <div style="background: rgba(59, 130, 246, 0.08); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 12px; padding: 14px 18px; margin-bottom: 1.5rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
            <div style="display: flex; align-items: center; gap: 12px;">
                <span class="material-icons" style="font-size: 28px; color: #2563eb;">download_for_offline</span>
                <div>
                    <strong style="color: #1e40af; font-size: 0.95rem;">
                        <?php echo __a('admin.plugins.missing_official_title', 'Offizielle Plugins nachinstallieren ({count})', null, ['count' => count($missing_official)]); ?>
                    </strong>
                    <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 2px;">
                        <?php echo __a('admin.plugins.missing_official_desc', 'Folgende im Release enthaltene Plugins sind noch nicht auf diesem Server vorhanden: {plugins}', null, ['plugins' => '<code>' . htmlspecialchars(implode(', ', $missing_official)) . '</code>']); ?>
                    </div>
                </div>
            </div>
            <form method="POST" action="" style="margin: 0;">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                <input type="hidden" name="action" value="sync_missing_plugins">
                <button type="submit" class="btn btn-primary" style="padding: 7px 16px; font-size: 0.85rem; display: inline-flex; align-items: center; gap: 6px;">
                    <span class="material-icons" style="font-size: 16px;">cloud_download</span>
                    <?php echo __a('admin.plugins.btn_sync_missing', 'Fehlende Plugins jetzt nachinstallieren'); ?>
                </button>
            </form>
        </div>
    <?php endif; ?>

    <?php if (empty($all_plugins)): ?>
        <div style="background: rgba(0,0,0,0.02); border: 2px dashed var(--border-color); border-radius: 16px; padding: 3rem 2rem; text-align:center;">
            <span class="material-icons" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 1rem;">extension_off</span>
            <h3 style="font-size: 1.25rem; margin-bottom: 0.5rem;"><?php echo __a('admin.plugins.empty_title', 'Keine Plugins gefunden'); ?></h3>
            <p style="color: var(--text-secondary); font-size: 0.95rem; max-width: 520px; margin: 0 auto; line-height: 1.5;">
                <?php echo __a('admin.plugins.empty_desc', 'Es wurden bisher keine Erweiterungen im Verzeichnis plugins/ hinterlegt. Lege einfach einen Unterordner mit einer plugin.json an, um eine neue Erweiterung zu registrieren.'); ?>
            </p>
        </div>
    <?php else: ?>
        <div class="plugin-grid" style="display:grid; grid-template-columns: 1fr; gap: 1.5rem; margin-bottom: 2rem;">
            <?php foreach ($all_plugins as $slug => $plugin): 
                $isActive = !empty($plugin['active']);
                $settingsKey = $plugin['settings_tab'] ?? '';
                $hasSettings = PluginManager::hasAction("admin_render_plugin_settings_{$slug}")
                            || (!empty($settingsKey) && PluginManager::hasAction("admin_render_plugin_settings_{$settingsKey}"));
                $isConfigOpen = ($active_settings_slug === $slug || (!empty($settingsKey) && $active_settings_slug === $settingsKey));
                $pluginIssues = $isActive ? PluginManager::getMissingSettings($slug, $data) : [];
            ?>
                <div class="plugin-card" style="border: 1px solid <?php echo $isActive ? (!empty($pluginIssues) ? '#f59e0b' : 'rgba(46,98,72,0.3)') : 'var(--border-color)'; ?>; border-radius: 16px; background: <?php echo $isActive ? (!empty($pluginIssues) ? 'rgba(245,158,11,0.02)' : 'rgba(46,98,72,0.02)') : 'var(--card-bg, #fff)'; ?>; padding: 1.75rem; box-shadow: 0 4px 15px rgba(0,0,0,0.03); transition: all 0.2s;">
                    <div style="display:flex; align-items:flex-start; justify-content:space-between; flex-wrap:wrap; gap: 1rem; margin-bottom: 1rem;">
                        <div style="display:flex; align-items:flex-start; gap: 16px;">
                            <div style="width: 54px; height: 54px; border-radius: 14px; background: <?php echo $isActive ? (!empty($pluginIssues) ? 'rgba(245,158,11,0.15)' : 'rgba(46,98,72,0.12)') : 'rgba(0,0,0,0.05)'; ?>; color: <?php echo $isActive ? (!empty($pluginIssues) ? '#d97706' : 'var(--primary)') : 'var(--text-secondary)'; ?>; display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                                <span class="material-icons" style="font-size: 32px;"><?php echo htmlspecialchars($plugin['icon'] ?? 'extension'); ?></span>
                            </div>
                            <div>
                                <div style="display:flex; align-items:center; gap: 8px; flex-wrap:wrap;">
                                    <h3 style="margin:0; font-size: 1.25rem;"><?php echo htmlspecialchars($plugin['name']); ?></h3>
                                    <span style="font-size:0.75rem; font-weight:700; background:rgba(0,0,0,0.06); color:var(--text-secondary); padding:2px 8px; border-radius:6px;">
                                        v<?php echo htmlspecialchars($plugin['version']); ?>
                                    </span>
                                    <?php if (!empty($plugin_updates[$slug])): ?>
                                        <a href="<?php echo htmlspecialchars($plugin_updates[$slug]['release_url']); ?>" target="_blank" style="font-size:0.75rem; font-weight:700; background:#fef3c7; color:#b45309; border:1px solid #f59e0b; padding:2px 8px; border-radius:6px; text-decoration:none; display:inline-flex; align-items:center; gap:3px;">
                                            <span class="material-icons" style="font-size:12px;">update</span> Update v<?php echo htmlspecialchars($plugin_updates[$slug]['latest_version']); ?>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (!empty($pluginIssues)): ?>
                                        <span style="font-size:0.75rem; font-weight:700; background:#fef3c7; color:#b45309; border:1px solid #f59e0b; padding:2px 8px; border-radius:6px; display:inline-flex; align-items:center; gap:3px;">
                                            <span class="material-icons" style="font-size:12px;">warning</span> <?php echo __a('admin.plugins.settings_incomplete', 'Einstellungen unvollständig'); ?>
                                        </span>
                                    <?php endif; ?>
                                    <span style="font-size:0.75rem; font-weight:700; text-transform:uppercase; background:rgba(178,108,57,0.1); color:var(--accent); padding:2px 8px; border-radius:6px;">
                                        <?php echo htmlspecialchars($plugin['category']); ?>
                                    </span>
                                </div>
                                <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 3px;">
                                    <?php echo __a('admin.plugins.author_info', 'Von {author} • Slug: {slug}', null, [
                                        'author' => '<strong>' . htmlspecialchars($plugin['author']) . '</strong>',
                                        'slug' => '<code>' . htmlspecialchars($slug) . '</code>'
                                    ]); ?>
                                    <?php 
                                    $repoTarget = $plugin['github_repo'] ?? $plugin['repository'] ?? null;
                                    if (!empty($repoTarget)): 
                                        $repoUrl = str_starts_with($repoTarget, 'http') ? $repoTarget : 'https://github.com/' . ltrim($repoTarget, '/');
                                    ?>
                                        • <a href="<?php echo htmlspecialchars($repoUrl); ?>" target="_blank" rel="noopener noreferrer" style="color:var(--primary); text-decoration:none; display:inline-flex; align-items:center; gap:3px;">
                                            <span class="material-icons" style="font-size:13px;">code</span> <?php echo htmlspecialchars(basename(parse_url($repoUrl, PHP_URL_PATH) ?? 'Repo')); ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Status & Toggle -->
                        <div style="display:flex; align-items:center; gap: 10px; flex-wrap:wrap;">
                            <?php if (!empty($plugin['github_repo']) || !empty($plugin['repository']) || !empty($plugin['update_url'])): ?>
                                <form method="POST" action="" style="display:inline; margin:0;">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                    <input type="hidden" name="action" value="check_plugin_update">
                                    <input type="hidden" name="plugin_slug" value="<?php echo htmlspecialchars($slug); ?>">
                                    <button type="submit" class="btn btn-outline" style="display:inline-flex; align-items:center; gap:5px; font-size:0.85rem; padding: 7px 11px;" title="<?php echo htmlspecialchars(__a('admin.plugins.btn_check_plugin_update_tip', 'Dieses Plugin auf GitHub/Server nach Updates prüfen')); ?>">
                                        <span class="material-icons" style="font-size:15px;">sync</span> <?php echo __a('admin.plugins.btn_check_plugin_update', 'Update prüfen'); ?>
                                    </button>
                                </form>
                            <?php endif; ?>

                            <form method="POST" action="" style="display:inline; margin:0;">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <input type="hidden" name="action" value="toggle_plugin">
                                <input type="hidden" name="plugin_slug" value="<?php echo htmlspecialchars($slug); ?>">
                                <input type="hidden" name="target_state" value="<?php echo $isActive ? '0' : '1'; ?>">

                                <?php if ($isActive): ?>
                                    <button type="submit" class="btn btn-outline" style="display:inline-flex; align-items:center; gap:6px; font-size:0.88rem; padding: 7px 14px; border-color:#f87171; color:#ef4444;" title="<?php echo htmlspecialchars(__a('admin.plugins.btn_deactivate', 'Deaktivieren')); ?>">
                                        <span class="material-icons" style="font-size:16px;">power_settings_new</span> <?php echo __a('admin.plugins.btn_deactivate', 'Deaktivieren'); ?>
                                    </button>
                                <?php else: ?>
                                    <button type="submit" class="btn btn-primary" style="display:inline-flex; align-items:center; gap:6px; font-size:0.88rem; padding: 7px 16px;" title="<?php echo htmlspecialchars(__a('admin.plugins.btn_activate', 'Aktivieren')); ?>">
                                        <span class="material-icons" style="font-size:16px;">bolt</span> <?php echo __a('admin.plugins.btn_activate', 'Aktivieren'); ?>
                                    </button>
                                <?php endif; ?>
                            </form>

                            <?php if ($isActive && $hasSettings): ?>
                                <button type="button" class="btn btn-secondary" onclick="togglePluginSettings('<?php echo htmlspecialchars($slug); ?>')" style="display:inline-flex; align-items:center; gap:6px; font-size:0.88rem; padding: 7px 14px;">
                                    <span class="material-icons" style="font-size:16px;">tune</span> <?php echo __a('admin.plugins.btn_settings', 'Einstellungen'); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if (!empty($plugin_updates[$slug]) && !empty($plugin_updates[$slug]['update_available'])): 
                        $pUp = $plugin_updates[$slug];
                    ?>
                        <div style="background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.35); border-radius: 8px; padding: 10px 14px; margin-bottom: 1rem; font-size: 0.88rem; color: #92400e; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <span class="material-icons" style="font-size: 20px; color: #d97706; flex-shrink: 0;">system_update_alt</span>
                                <div>
                                    <strong><?php echo __a('admin.plugins.update_available_title', 'Update verfügbar:'); ?> v<?php echo htmlspecialchars($plugin['version']); ?> &rarr; v<?php echo htmlspecialchars($pUp['latest_version']); ?></strong>
                                    <?php if (!empty($pUp['release_url'])): ?>
                                        <a href="<?php echo htmlspecialchars($pUp['release_url']); ?>" target="_blank" rel="noopener noreferrer" style="color: #b45309; text-decoration: underline; margin-left: 8px; font-size: 0.82rem;"><?php echo __a('admin.plugins.view_changelog', 'Changelog ansehen →'); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <form method="POST" action="" onsubmit="return confirm('<?php echo htmlspecialchars(addslashes(__a('admin.plugins.confirm_update', 'Möchtest du das Plugin jetzt wirklich auf die neue Version aktualisieren? Ein automatisches Backup wird vor dem Update erstellt.'))); ?>');" style="margin: 0;">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                <input type="hidden" name="action" value="update_plugin">
                                <input type="hidden" name="plugin_slug" value="<?php echo htmlspecialchars($slug); ?>">
                                <button type="submit" class="btn" style="background: #f59e0b; color: #fff; font-weight: 600; padding: 6px 14px; font-size: 0.85rem; border: none; border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
                                    <span class="material-icons" style="font-size: 16px;">download</span>
                                    <?php echo __a('admin.plugins.btn_install_update', 'Jetzt auf v{version} aktualisieren', null, ['version' => htmlspecialchars($pUp['latest_version'])]); ?>
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($pluginIssues)): ?>
                        <div style="background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: 8px; padding: 8px 12px; margin-bottom: 1rem; font-size: 0.85rem; color: #92400e; display: flex; align-items: center; gap: 8px;">
                            <span class="material-icons" style="font-size: 18px; color: #d97706; flex-shrink: 0;">warning</span>
                            <div>
                                <strong><?php echo __a('admin.plugins.missing_req_settings', 'Erforderliche Einstellungen fehlen:'); ?></strong>
                                <span><?php echo htmlspecialchars(implode(' • ', $pluginIssues)); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <p style="color: var(--text-secondary); font-size: 0.92rem; line-height: 1.5; margin: 0 0 1rem 0;">
                        <?php echo htmlspecialchars($plugin['description']); ?>
                    </p>

                    <div style="display:flex; align-items:center; justify-content:space-between; font-size: 0.82rem; color: var(--text-secondary); padding-top: 0.75rem; border-top: 1px solid rgba(0,0,0,0.06);">
                        <div style="display:flex; align-items:center; gap: 6px;">
                            <span class="material-icons" style="font-size: 16px; color: <?php echo $isActive ? '#10b981' : '#94a3b8'; ?>;">
                                <?php echo $isActive ? 'check_circle' : 'radio_button_unchecked'; ?>
                            </span>
                            <span><?php echo __a('admin.plugins.status_label', 'Status:'); ?> <strong><?php echo $isActive ? __a('admin.status.active', 'Aktiv') : __a('admin.status.disabled', 'Deaktiviert'); ?></strong></span>
                        </div>
                        <div>
                            <span><?php echo __a('admin.plugins.compat_label', 'Core-Kompatibilität:'); ?> <code><?php echo htmlspecialchars($plugin['requires_core']); ?></code></span>
                        </div>
                    </div>

                    <!-- Einstellungen (Drawer) -->
                    <?php if ($isActive && $hasSettings): ?>
                        <div id="plugin-settings-drawer-<?php echo htmlspecialchars($slug); ?>" style="display: <?php echo $isConfigOpen ? 'block' : 'none'; ?>; margin-top: 1.5rem; border-top: 1px dashed var(--border-color); padding-top: 1rem;">
                            <?php 
                                if (PluginManager::hasAction("admin_render_plugin_settings_{$slug}")) {
                                    PluginManager::doAction("admin_render_plugin_settings_{$slug}", $data, $csrf_token);
                                } elseif (!empty($settingsKey) && PluginManager::hasAction("admin_render_plugin_settings_{$settingsKey}")) {
                                    PluginManager::doAction("admin_render_plugin_settings_{$settingsKey}", $data, $csrf_token);
                                }
                            ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
function togglePluginSettings(slug) {
    const el = document.getElementById('plugin-settings-drawer-' + slug);
    if (!el) return;
    const isHidden = (el.style.display === 'none' || el.style.display === '');
    el.style.display = isHidden ? 'block' : 'none';
    if (window.history && window.history.replaceState) {
        const url = new URL(window.location.href);
        url.searchParams.set('tab', 'tab-plugins');
        if (isHidden) {
            url.searchParams.set('plugin_settings', slug);
        } else {
            url.searchParams.delete('plugin_settings');
        }
        history.replaceState(null, '', url.pathname + url.search + '#tab-plugins');
    }
    if (isHidden) {
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}
</script>
