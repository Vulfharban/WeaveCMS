<?php
/**
 * Test suite for Website-Typ & Schnellstart-Profile and Plugin Missing Settings
 */

require_once __DIR__ . '/../../config.php';

echo "=== Test Suite: Presets & Plugin Missing Settings ===\n";

// 1. Test Presets structure
$presets = SectionManager::getPresets();
assert(count($presets) >= 6, "Should have at least 6 presets");
assert(isset($presets['portfolio']), "Preset portfolio must exist");
assert(isset($presets['business']), "Preset business must exist");
assert(isset($presets['blog']), "Preset blog must exist");
assert(isset($presets['workshops']), "Preset workshops must exist");
assert(isset($presets['shop']), "Preset shop must exist");
assert(isset($presets['minimal']), "Preset minimal must exist");
assert(isset($presets['all']), "Preset all must exist");
echo "PASS: Presets list verified (" . count($presets) . " presets available)\n";

// 2. Test applyPreset('workshops')
$mockData = [
    'sections' => SectionManager::getDefaultSections(),
    'plugins' => ['active' => [], 'configs' => []],
    'settings' => []
];

$res = SectionManager::applyPreset('workshops', $mockData);
assert($res === true, "applyPreset('workshops') should return true");
assert($mockData['settings']['project_preset'] === 'workshops', "Preset key should be stored in settings");
assert(in_array('weave-workshops', $mockData['plugins']['active'], true), "weave-workshops plugin must be activated");

$visibleTypes = [];
foreach ($mockData['sections'] as $s) {
    if (!empty($s['visible'])) {
        $visibleTypes[] = $s['type'] ?? $s['id'];
    }
}
assert(in_array('courses', $visibleTypes, true), "courses must be visible");
assert(in_array('past_courses', $visibleTypes, true), "past_courses must be visible");
assert(in_array('about', $visibleTypes, true), "about must be visible");
assert(!in_array('blog', $visibleTypes, true), "blog must be hidden in workshops preset");
echo "PASS: applyPreset('workshops') successfully enabled modules and weave-workshops plugin\n";

// 3. Test applyPreset('shop')
$res = SectionManager::applyPreset('shop', $mockData);
assert($res === true, "applyPreset('shop') should return true");
assert(in_array('shop', $mockData['plugins']['active'], true), "shop plugin must be activated");
assert(in_array('inventory', $mockData['plugins']['active'], true), "inventory plugin must be activated");
assert(!empty($mockData['plugins']['configs']['shop']['section_enabled']), "shop section_enabled must be true");

$visibleShopTypes = [];
foreach ($mockData['sections'] as $s) {
    if (!empty($s['visible'])) {
        $visibleShopTypes[] = $s['type'] ?? $s['id'];
    }
}
assert(in_array('shop', $visibleShopTypes, true), "shop section must be visible");
assert(in_array('gallery', $visibleShopTypes, true), "gallery must be visible");
assert(!in_array('courses', $visibleShopTypes, true), "courses must be hidden in shop preset");
echo "PASS: applyPreset('shop') successfully enabled shop modules, configs and plugins\n";

// 4. Test applyPreset('all')
$res = SectionManager::applyPreset('all', $mockData);
assert($res === true, "applyPreset('all') should return true");
assert(in_array('shop', $mockData['plugins']['active'], true), "shop plugin active");
assert(in_array('inventory', $mockData['plugins']['active'], true), "inventory plugin active");
assert(in_array('weave-workshops', $mockData['plugins']['active'], true), "weave-workshops plugin active");
assert(in_array('weave-downloads', $mockData['plugins']['active'], true), "weave-downloads plugin active");

foreach ($mockData['sections'] as $s) {
    assert(!empty($s['visible']), "All sections must be visible in 'all' preset: " . ($s['id'] ?? ''));
}
echo "PASS: applyPreset('all') successfully enabled every module, section and plugin\n";

// 5. Test PluginManager::getMissingSettings for shop
$unconfiguredShopData = [
    'plugins' => [
        'active' => ['shop'],
        'configs' => [
            'shop' => [
                'currency' => 'EUR'
                // No payment methods
            ]
        ]
    ]
];
$shopIssues = PluginManager::getMissingSettings('shop', $unconfiguredShopData);
assert(!empty($shopIssues), "Unconfigured shop should report missing payment methods");
assert(str_contains(implode(' ', $shopIssues), 'Zahlungsart'), "Issue should mention payment methods: " . implode(', ', $shopIssues));
echo "PASS: PluginManager::getMissingSettings('shop') detected missing payments\n";

// Now configure a payment method (e.g. Bank transfer with IBAN)
$configuredShopData = [
    'plugins' => [
        'active' => ['shop'],
        'configs' => [
            'shop' => [
                'currency' => 'EUR',
                'payment_bank_transfer' => [
                    'enabled' => true,
                    'iban' => 'DE12345678901234567890'
                ]
            ]
        ]
    ]
];
$resolvedShopIssues = PluginManager::getMissingSettings('shop', $configuredShopData);
assert(empty($resolvedShopIssues), "Configured shop should report 0 issues: " . json_encode($resolvedShopIssues));
echo "PASS: PluginManager::getMissingSettings('shop') reports 0 issues once payment is configured\n";

// 6. Test PluginManager::getAllMissingSettings
$mockAllData = [
    'plugins' => [
        'active' => ['shop', 'universal-integrations'],
        'configs' => [
            'shop' => []
        ]
    ],
    'integrations' => []
];
$allMissing = PluginManager::getAllMissingSettings($mockAllData);
assert(isset($allMissing['shop']), "shop should be in allMissing");
assert(isset($allMissing['universal-integrations']), "universal-integrations should be in allMissing");
echo "PASS: PluginManager::getAllMissingSettings detected issues for all active unconfigured plugins\n";

echo "\n>>> ALL 6 TESTS PASSED SUCCESSFULLY! <<<\n";
