<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../libs/php/FrontendController.php';

$vm = [
    'is_preview_mode' => true,
    'preview_title' => 'Entwurfs-Artikel',
    'preview_status' => 'draft',
    'primary_color' => '#2e6248'
];

ob_start();
FrontendController::renderPreviewBanner($vm);
$banner = ob_get_clean();

assert(strpos($banner, 'weave-preview-banner') !== false, 'Banner container exists');
assert(strpos($banner, 'Vorschau-Modus') !== false, 'Banner contains title');
assert(strpos($banner, 'Entwurf') !== false, 'Banner contains status');

echo "Preview Banner HTML:\n" . $banner . "\n";
echo ">>> PREVIEW BANNER TEST PASSED! <<<\n";
