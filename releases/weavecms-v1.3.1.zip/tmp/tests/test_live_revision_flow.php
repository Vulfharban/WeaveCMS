<?php
require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../libs/php/RevisionManager.php';

$dataFile = __DIR__ . '/../../data.json';
$data = json_decode(file_get_contents($dataFile), true);

if (empty($data['pages'])) {
    echo "No pages found in data.json\n";
    exit(1);
}

$page = &$data['pages'][0];
$pageId = $page['id'];
$pageTitle = $page['title'];

echo "Testing revision and rollback workflow on page: [{$pageId}] {$pageTitle}\n";

// 1. Initial snapshot
$rev1 = RevisionManager::createRevision('page', $pageId, $page, 'Redakteur', 'Ausgangszustand für Test');
echo "Created Rev 1: $rev1\n";

// 2. Modify page content
$origContent = $page['content'];
$page['content'] = $origContent . "\n\n### NEUER TEST-ABSCHNITT\nDies ist eine zusätzliche Testzeile für den Revisions-Diff.";
$rev2 = RevisionManager::createRevision('page', $pageId, $page, 'Redakteur', 'Testzeile hinzugefügt');
echo "Created Rev 2: $rev2\n";

// 3. Diff test
$rev1Data = RevisionManager::getRevision('page', $pageId, $rev1);
$diff = RevisionManager::computeDiff($rev1Data['data']['content'], $page['content']);
echo "Diff entries: " . count($diff) . "\n";
$html = RevisionManager::renderDiffHtml($diff);
echo "Diff HTML length: " . strlen($html) . "\n";

// 4. Rollback to Rev 1
$rollback = RevisionManager::rollbackRevision('page', $pageId, $rev1, $data, 'Admin');
if ($rollback['success']) {
    echo "Rollback successful: {$rollback['message']}\n";
    if ($data['pages'][0]['content'] === $origContent) {
        echo "VERIFIED: Page content was perfectly restored to original content!\n";
    } else {
        echo "ERROR: Restored content does not match original!\n";
        exit(1);
    }
} else {
    echo "ERROR: Rollback failed: {$rollback['message']}\n";
    exit(1);
}

// 5. Clean up test revisions
$revFile = RevisionManager::getStorageDir() . '/page_' . $pageId . '.json';
if (file_exists($revFile)) {
    unlink($revFile);
    echo "Test revisions cleaned up.\n";
}

echo "=== All Live Revision Workflow Tests Passed! ===\n";
