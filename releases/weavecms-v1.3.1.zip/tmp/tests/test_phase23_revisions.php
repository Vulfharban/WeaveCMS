<?php
/**
 * Test Suite for Phase 23 (Paket 2): Content-Revisions & Entwurfsmodus
 */

require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../../libs/php/RevisionManager.php';

echo "=== Running Phase 23 (RevisionManager & Entwurfsmodus) Test Suite ===\n";

$testsPassed = 0;
$testsFailed = 0;

function assertCondition(bool $cond, string $name) {
    global $testsPassed, $testsFailed;
    if ($cond) {
        echo " [PASS] $name\n";
        $testsPassed++;
    } else {
        echo " [FAIL] $name\n";
        $testsFailed++;
    }
}

// 1. Preview Token Generation
$token1 = RevisionManager::generatePreviewToken();
$token2 = RevisionManager::generatePreviewToken();
assertCondition(strlen($token1) === 32, "Preview token length is 32 chars");
assertCondition($token1 !== $token2, "Preview tokens are unique");

// 2. Visibility Matrix
$publishedItem = ['status' => 'published', 'title' => 'Öffentlich'];
$draftItem = ['status' => 'draft', 'title' => 'Entwurf', 'preview_token' => $token1];
$scheduledFuture = [
    'status' => 'scheduled',
    'title' => 'Geplant Zukunft',
    'publish_at' => date('Y-m-d H:i:s', time() + 3600),
    'preview_token' => $token1
];
$scheduledPast = [
    'status' => 'scheduled',
    'title' => 'Geplant Vergangenheit',
    'publish_at' => date('Y-m-d H:i:s', time() - 3600),
    'preview_token' => $token1
];

// Guest visitor (no session)
unset($_SESSION['admin_logged_in']);
assertCondition(RevisionManager::isItemVisible($publishedItem) === true, "Published item visible to guest");
assertCondition(RevisionManager::isItemVisible($draftItem) === false, "Draft item hidden from guest without token");
assertCondition(RevisionManager::isItemVisible($draftItem, 'wrong_token') === false, "Draft item hidden with wrong token");
assertCondition(RevisionManager::isItemVisible($draftItem, $token1) === true, "Draft item visible with valid preview token");
assertCondition(RevisionManager::isItemVisible($scheduledFuture) === false, "Future scheduled item hidden without token");
assertCondition(RevisionManager::isItemVisible($scheduledFuture, $token1) === true, "Future scheduled item visible with valid preview token");
assertCondition(RevisionManager::isItemVisible($scheduledPast) === true, "Past scheduled item auto-published / visible to guest");

// Admin visitor
$_SESSION['admin_logged_in'] = true;
assertCondition(RevisionManager::isItemVisible($draftItem) === true, "Draft item visible to logged-in admin");
assertCondition(RevisionManager::isItemVisible($scheduledFuture) === true, "Future scheduled item visible to logged-in admin");
unset($_SESSION['admin_logged_in']);

// 3. Preview mode detection
assertCondition(RevisionManager::isPreviewMode($publishedItem) === false, "Published item is not in preview mode");
assertCondition(RevisionManager::isPreviewMode($draftItem, $token1) === true, "Draft item with token is in preview mode");
assertCondition(RevisionManager::isPreviewMode($scheduledFuture, $token1) === true, "Future scheduled item with token is in preview mode");
assertCondition(RevisionManager::isPreviewMode($scheduledPast) === false, "Past scheduled item is not in preview mode");

// 4. Revision Storage, Retrieval & Rollback
$testItemId = 'test_page_' . uniqid();
$initialPageData = [
    'id' => $testItemId,
    'title' => 'Original Seitentitel',
    'slug' => 'original-seite',
    'content' => "## Einleitung\nDies ist der ursprüngliche Text der Seite.\nZeile 2 original.",
    'status' => 'draft',
    'preview_token' => $token1
];

$revId1 = RevisionManager::createRevision('page', $testItemId, $initialPageData, 'Redakteur 1', 'Erste Version erstellt');
assertCondition(!empty($revId1), "Initial revision created: $revId1");

$revList = RevisionManager::getRevisions('page', $testItemId);
assertCondition(count($revList) === 1, "Revision list contains 1 entry");
assertCondition($revList[0]['rev_id'] === $revId1, "Revision ID in list matches");

$revFull = RevisionManager::getRevision('page', $testItemId, $revId1);
assertCondition($revFull !== null && $revFull['data']['title'] === 'Original Seitentitel', "Full revision data matches");

// Second Revision
$updatedPageData = $initialPageData;
$updatedPageData['title'] = 'Neuer Seitentitel V2';
$updatedPageData['content'] = "## Einleitung\nDies ist der AKTUALISIERTE Text der Seite.\nZeile 2 original.\nNeue Zeile 3 hinzugefügt.";
$revId2 = RevisionManager::createRevision('page', $testItemId, $updatedPageData, 'Redakteur 2', 'Inhalt aktualisiert');

$revList2 = RevisionManager::getRevisions('page', $testItemId);
assertCondition(count($revList2) === 2, "Revision list now contains 2 entries");
assertCondition($revList2[0]['rev_id'] === $revId2, "Latest revision is first in list");

// 5. Diff Computation & HTML Rendering
$diff = RevisionManager::computeDiff($initialPageData['content'], $updatedPageData['content']);
$hasAdded = false;
$hasRemoved = false;
foreach ($diff as $d) {
    if ($d['type'] === 'added') $hasAdded = true;
    if ($d['type'] === 'removed') $hasRemoved = true;
}
assertCondition($hasAdded && $hasRemoved, "Diff correctly detected additions and deletions");

$diffHtml = RevisionManager::renderDiffHtml($diff);
assertCondition(strpos($diffHtml, 'revision-diff-container') !== false, "Diff HTML renders container");
assertCondition(strpos($diffHtml, '+ ') !== false, "Diff HTML contains addition marker");

// 6. Rollback
$mockGlobalData = [
    'pages' => [
        $updatedPageData
    ]
];

$rollbackResult = RevisionManager::rollbackRevision('page', $testItemId, $revId1, $mockGlobalData, 'Admin');
assertCondition($rollbackResult['success'] === true, "Rollback executed successfully");
assertCondition($mockGlobalData['pages'][0]['title'] === 'Original Seitentitel', "Restored item title matches V1");
assertCondition(strpos($mockGlobalData['pages'][0]['content'], 'ursprüngliche') !== false, "Restored item content matches V1");

// 7. Storage Dir & .htaccess Protection
$storageDir = RevisionManager::getStorageDir();
assertCondition(is_dir($storageDir), "Revisions storage directory exists");
assertCondition(file_exists($storageDir . '/.htaccess'), ".htaccess protection file exists in revisions dir");
$htaccessContent = file_get_contents($storageDir . '/.htaccess');
assertCondition(strpos($htaccessContent, 'Deny from all') !== false, ".htaccess contains 'Deny from all'");

// Clean up test revisions file
$testRevFile = $storageDir . '/page_' . $testItemId . '.json';
if (file_exists($testRevFile)) {
    @unlink($testRevFile);
}

echo "\nSummary: $testsPassed passed, $testsFailed failed.\n";
if ($testsFailed === 0) {
    echo ">>> ALL PHASE 23 TESTS PASSED SUCCESSFULLY! <<<\n";
} else {
    exit(1);
}
