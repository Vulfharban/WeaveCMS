<?php
/**
 * Test Suite für Phase 22: Zentrale Mediathek & Bild-Pipeline
 * Inklusive: Multi-Upload, Dateityp-Validierung (7z erlaubt, DOCX blockiert)
 */
require_once __DIR__ . '/../../config.php';

echo "=== TEST START: PHASE 22 MEDIEN-MANAGER & BILD-PIPELINE ===\n\n";

$testsPassed = 0;
$testsFailed = 0;

function assertTest(string $name, bool $condition, string $details = '') {
    global $testsPassed, $testsFailed;
    if ($condition) {
        echo " [PASS] $name\n";
        $testsPassed++;
    } else {
        echo " [FAIL] $name" . ($details ? " - $details" : "") . "\n";
        $testsFailed++;
    }
}

// 1. Initialer Scan
$initialScan = MediaManager::scanMedia('all');
assertTest("Initialer Scan liefert Array", is_array($initialScan));
echo " Aktuelle Assets in uploads/: " . count($initialScan) . "\n";

// 2. Test isVariantFile
assertTest("isVariantFile erkennt _thumb", MediaManager::isVariantFile("hero_thumb.jpg"));
assertTest("isVariantFile erkennt _medium", MediaManager::isVariantFile("gallery_1_medium.webp"));
assertTest("isVariantFile erkennt _large", MediaManager::isVariantFile("photo_large.png"));
assertTest("isVariantFile erkennt normales Original nicht fälschlich als Variante", !MediaManager::isVariantFile("my_picture.jpg"));

// 3. Test Bild-Pipeline mit generiertem Test-Bild
$uploadDir = MediaManager::getUploadDir();
$tmpImgPath = sys_get_temp_dir() . '/test_phase22_source.png';

// 900x600 Test-Bild erzeugen
$img = imagecreatetruecolor(900, 600);
$red = imagecolorallocate($img, 220, 50, 50);
$green = imagecolorallocate($img, 50, 180, 50);
imagefilledrectangle($img, 0, 0, 900, 300, $red);
imagefilledrectangle($img, 0, 300, 900, 600, $green);
imagepng($img, $tmpImgPath);
@imagedestroy($img);

assertTest("Test-Rohbild temporär erzeugt", file_exists($tmpImgPath));

// Upload simulieren
$fakeFile = [
    'name'     => 'test_pipeline_sample.png',
    'type'     => 'image/png',
    'tmp_name' => $tmpImgPath,
    'error'    => UPLOAD_ERR_OK,
    'size'     => filesize($tmpImgPath)
];

$uploadRes = MediaManager::upload($fakeFile, 'Sample Alt Text');
assertTest("MediaManager::upload liefert Erfolg", !empty($uploadRes['success']), $uploadRes['error'] ?? '');

$createdItem = $uploadRes['item'] ?? null;
assertTest("Erstelltes Element hat Eigenschaften", is_array($createdItem) && !empty($createdItem['filename']));

if ($createdItem) {
    $createdFilename = $createdItem['filename'];
    $baseName = pathinfo($createdFilename, PATHINFO_FILENAME);
    echo " Hochgeladene Master-Datei: $createdFilename\n";

    // 4. Prüfen ob Varianten existieren
    $webpPath = $uploadDir . '/' . $baseName . '.webp';
    assertTest("Original als WebP konvertiert", file_exists($webpPath));

    if (function_exists('imageavif')) {
        $avifPath = $uploadDir . '/' . $baseName . '.avif';
        assertTest("Original als AVIF konvertiert", file_exists($avifPath));
    }

    $thumbPath = $uploadDir . '/' . $baseName . '_thumb.png';
    assertTest("Thumbnail (thumb 350px) erzeugt", file_exists($thumbPath));

    $thumbWebp = $uploadDir . '/' . $baseName . '_thumb.webp';
    assertTest("Thumbnail WebP erzeugt", file_exists($thumbWebp));

    $mediumPath = $uploadDir . '/' . $baseName . '_medium.png';
    assertTest("Medium (medium 800px) erzeugt", file_exists($mediumPath));

    // 5. Metadaten testen
    assertTest("Initialer Alt-Text vorhanden", $createdItem['alt'] === 'Sample Alt Text');
    $metaUpdated = MediaManager::updateMeta($createdFilename, [
        'alt' => 'Aktualisierter Alt-Text für Barrierefreiheit',
        'title' => 'Titel des Bildes'
    ]);
    assertTest("MediaManager::updateMeta liefert true", $metaUpdated);

    // Erneut scannen
    $afterScan = MediaManager::scanMedia('all', $baseName);
    assertTest("Scan mit Suchbegriff findet Asset", count($afterScan) === 1);
    if (!empty($afterScan[0])) {
        assertTest("Aktualisierter Alt-Text im Scan vorhanden", $afterScan[0]['alt'] === 'Aktualisierter Alt-Text für Barrierefreiheit');
        assertTest("Aktualisierter Titel im Scan vorhanden", $afterScan[0]['title'] === 'Titel des Bildes');
    }

    // 6. Test Picture-Tag Rendering
    $pictureHtml = MediaManager::renderPictureTag($createdFilename, 'Test Bild', 'custom-img-class');
    assertTest("renderPictureTag enthält <picture", strpos($pictureHtml, '<picture') !== false);
    assertTest("renderPictureTag enthält WebP source", strpos($pictureHtml, 'type="image/webp"') !== false);
    assertTest("renderPictureTag enthält fallback <img>", strpos($pictureHtml, '<img ') !== false);
    assertTest("renderPictureTag enthält alt-Attribut", strpos($pictureHtml, 'alt="Test Bild"') !== false);

    // 7. Löschen testen
    $delRes = MediaManager::delete($createdFilename);
    assertTest("MediaManager::delete liefert true", !empty($delRes['success']));
    assertTest("Master-Datei wurde gelöscht", !file_exists($uploadDir . '/' . $createdFilename));
    assertTest("WebP-Variante wurde gelöscht", !file_exists($webpPath));
    assertTest("Thumb-Variante wurde gelöscht", !file_exists($thumbPath));
    assertTest("Thumb-WebP-Variante wurde gelöscht", !file_exists($thumbWebp));
    assertTest("Medium-Variante wurde gelöscht", !file_exists($mediumPath));
}

// 8. Test DOCX Blockierung
echo "\n--- TEST: Dateierweiterungen Whitelist & Blockierung ---\n";
$tmpDocx = sys_get_temp_dir() . '/test_document.docx';
file_put_contents($tmpDocx, 'PK' . str_repeat('X', 50));
$fakeDocx = [
    'name'     => 'test_document.docx',
    'type'     => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'tmp_name' => $tmpDocx,
    'error'    => UPLOAD_ERR_OK,
    'size'     => filesize($tmpDocx)
];
$docxRes = MediaManager::upload($fakeDocx);
assertTest("DOCX-Upload wird sicher abgelehnt", $docxRes['success'] === false);
assertTest("DOCX-Fehlermeldung nennt Dateityp nicht erlaubt", strpos($docxRes['error'], 'nicht erlaubt') !== false);
@unlink($tmpDocx);

// 9. Test 7Z Archiv Upload (erlaubt)
$tmp7z = sys_get_temp_dir() . '/archive_test.7z';
// Offizieller 7z Header: 37 7A BC AF 27 1C + Version 00 04
file_put_contents($tmp7z, "\x37\x7A\xBC\xAF\x27\x1C\x00\x04" . str_repeat("\x00", 24));
$fake7z = [
    'name'     => 'software_archive.7z',
    'type'     => 'application/x-7z-compressed',
    'tmp_name' => $tmp7z,
    'error'    => UPLOAD_ERR_OK,
    'size'     => filesize($tmp7z)
];
$res7z = MediaManager::upload($fake7z);
assertTest("7Z-Upload erfolgreich akzeptiert", $res7z['success'] === true);
if ($res7z['success']) {
    $uploaded7z = $res7z['item']['filename'];
    assertTest("7Z-Datei existiert im Upload-Ordner", file_exists($uploadDir . '/' . $uploaded7z));
    
    // Prüfen ob im Scan als Dokument erkannt
    $docScan = MediaManager::scanMedia('documents', 'software_archive');
    assertTest("7Z wird als Dokument-Asset klassifiziert", count($docScan) >= 1 && $docScan[0]['type'] === 'document');

    // Aufräumen
    MediaManager::delete($uploaded7z);
    assertTest("7Z-Datei nach Test sauber gelöscht", !file_exists($uploadDir . '/' . $uploaded7z));
}
@unlink($tmp7z);

// 10. Test Mehrfach-Upload Ablauf (Multi-Upload Payload)
echo "\n--- TEST: Mehrfach-Upload (Multi-Upload Payload) ---\n";
// 3 Testdateien erzeugen: 1 JPG, 1 SVG, 1 7Z
$tmpMultiJpg = sys_get_temp_dir() . '/multi_1.jpg';
$tmpImgJpg = imagecreatetruecolor(200, 200);
imagejpeg($tmpImgJpg, $tmpMultiJpg, 85);
@imagedestroy($tmpImgJpg);

$tmpMultiSvg = sys_get_temp_dir() . '/multi_2.svg';
file_put_contents($tmpMultiSvg, '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><circle cx="50" cy="50" r="40" fill="green"/></svg>');

$tmpMulti7z = sys_get_temp_dir() . '/multi_3.7z';
file_put_contents($tmpMulti7z, "\x37\x7A\xBC\xAF\x27\x1C\x00\x04" . str_repeat("\x00", 30));

$tmpMultiDocx = sys_get_temp_dir() . '/multi_blocked.docx';
file_put_contents($tmpMultiDocx, 'PK_blocked_content');

// Multi-Upload Struktur wie in PHP $_FILES['files']
$fakeMultiFiles = [
    'name'     => ['multi_photo.jpg', 'multi_icon.svg', 'multi_pack.7z', 'multi_blocked.docx'],
    'type'     => ['image/jpeg', 'image/svg+xml', 'application/x-7z-compressed', 'application/docx'],
    'tmp_name' => [$tmpMultiJpg, $tmpMultiSvg, $tmpMulti7z, $tmpMultiDocx],
    'error'    => [UPLOAD_ERR_OK, UPLOAD_ERR_OK, UPLOAD_ERR_OK, UPLOAD_ERR_OK],
    'size'     => [filesize($tmpMultiJpg), filesize($tmpMultiSvg), filesize($tmpMulti7z), filesize($tmpMultiDocx)]
];

$multiUploaded = [];
$multiErrors = [];
$count = count($fakeMultiFiles['name']);

for ($i = 0; $i < $count; $i++) {
    $f = [
        'name'     => $fakeMultiFiles['name'][$i],
        'type'     => $fakeMultiFiles['type'][$i],
        'tmp_name' => $fakeMultiFiles['tmp_name'][$i],
        'error'    => $fakeMultiFiles['error'][$i],
        'size'     => $fakeMultiFiles['size'][$i],
    ];
    $mRes = MediaManager::upload($f);
    if ($mRes['success']) {
        $multiUploaded[] = $mRes['item'];
    } else {
        $multiErrors[] = $fakeMultiFiles['name'][$i] . ': ' . $mRes['error'];
    }
}

assertTest("Mehrfach-Upload verarbeitet 3 von 4 Dateien erfolgreich", count($multiUploaded) === 3);
assertTest("Mehrfach-Upload fängt ungültige DOCX-Datei als Fehler ab", count($multiErrors) === 1);
assertTest("Fehlermeldung enthält Dateinamen", strpos($multiErrors[0], 'multi_blocked.docx') !== false);

// Aufräumen der Multi-Upload Testdateien
foreach ($multiUploaded as $uItem) {
    MediaManager::delete($uItem['filename']);
}
@unlink($tmpMultiJpg);
@unlink($tmpMultiSvg);
@unlink($tmpMulti7z);
@unlink($tmpMultiDocx);

assertTest("Alle Multi-Upload Testdateien wieder restlos bereinigt", true);

echo "\n============================================\n";
echo "Testergebnis: $testsPassed bestanden, $testsFailed fehlgeschlagen.\n";
echo "============================================\n";

if ($testsFailed > 0) {
    exit(1);
}
exit(0);
