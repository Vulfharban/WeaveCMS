<?php
/**
 * Test script for Webshop & Inventory JSON Import/Export & API functionality
 */

$rootDir = file_exists(__DIR__ . '/../../plugins') ? dirname(__DIR__, 2) : dirname(__DIR__);
require_once $rootDir . '/plugins/shop/ShopManager.php';
require_once $rootDir . '/plugins/inventory/InventoryManager.php';

echo "=== 1. Testing ShopManager JSON Im/Export & API Key ===\n";

// API Key generation & verification with config
$shopKey = ShopManager::generateApiKey();
echo "Generated Shop API Key: " . substr($shopKey, 0, 8) . "...\n";
assert(str_starts_with($shopKey, 'wcsv_'), "Shop key should have wcsv_ prefix");
$mockShopConfig = ['api_key' => $shopKey, 'api_enabled' => true];
assert(ShopManager::verifyApiKey($shopKey, $mockShopConfig) === true, "Shop API Key should verify successfully with config");
assert(ShopManager::verifyApiKey("invalid_token", $mockShopConfig) === false, "Invalid API Key should fail verification");
assert(ShopManager::verifyApiKey("", $mockShopConfig) === false, "Empty API Key should fail verification");
echo "PASS: Shop API Key verification\n";

// Export
$productsJson = ShopManager::exportProductsJson();
assert(!empty($productsJson), "Exported products JSON should not be empty");
$decodedProducts = json_decode($productsJson, true);
assert(is_array($decodedProducts), "Exported products JSON should be valid array");
echo "PASS: ShopManager::exportProductsJson (" . count($decodedProducts) . " products exported)\n";

$ordersJson = ShopManager::exportOrdersJson();
assert(!empty($ordersJson), "Exported orders JSON should not be empty");
echo "PASS: ShopManager::exportOrdersJson\n";

// Import (test merge mode)
$testProduct = [
    [
        'id' => 'test_api_sku_1',
        'title' => 'API Test Produkt',
        'price' => 19.99,
        'stock' => 50,
        'category' => 'test'
    ]
];
$importResult = ShopManager::importProductsJson(json_encode($testProduct), 'merge');
assert($importResult['success'] === true, "Shop product import should succeed");
assert($importResult['imported'] >= 1 || $importResult['updated'] >= 1, "At least 1 product should be imported or updated");
echo "PASS: ShopManager::importProductsJson (merge mode)\n";

// Cleanup test product
ShopManager::deleteProduct('test_api_sku_1');
echo "PASS: Cleanup test product\n";

echo "\n=== 2. Testing InventoryManager JSON Im/Export & API Key ===\n";

// API Key generation & verification with config
$invKey = InventoryManager::generateApiKey();
echo "Generated Inventory API Key: " . substr($invKey, 0, 8) . "...\n";
assert(str_starts_with($invKey, 'wciv_'), "Inventory key should have wciv_ prefix");
$mockInvConfig = ['api_key' => $invKey, 'api_enabled' => true];
assert(InventoryManager::verifyApiKey($invKey, $mockInvConfig) === true, "Inventory API Key should verify successfully with config");
assert(InventoryManager::verifyApiKey("invalid_token", $mockInvConfig) === false, "Invalid Inventory API Key should fail verification");
echo "PASS: Inventory API Key verification\n";

// Export articles
$articlesJson = InventoryManager::exportArticlesJson();
assert(!empty($articlesJson), "Exported inventory articles JSON should not be empty");
$decodedArticles = json_decode($articlesJson, true);
assert(is_array($decodedArticles), "Exported inventory articles JSON should be valid array");
echo "PASS: InventoryManager::exportArticlesJson (" . count($decodedArticles) . " articles)\n";

// Export movements
$movementsJson = InventoryManager::exportMovementsJson();
assert(!empty($movementsJson), "Exported movements JSON should not be empty");
echo "PASS: InventoryManager::exportMovementsJson\n";

// Import test
$testArticle = [
    [
        'id' => 'test_inv_sku_1',
        'title' => 'Lager Test Artikel',
        'stock' => 25,
        'min_stock' => 5,
        'unit' => 'Stück'
    ]
];
$invImportResult = InventoryManager::importArticlesJson(json_encode($testArticle), 'merge', 'unit_test');
assert($invImportResult['success'] === true, "Inventory import should succeed");
echo "PASS: InventoryManager::importArticlesJson (merge mode)\n";

// Test stock adjustment (e.g. POS sale / reduction)
$adjustResult = InventoryManager::adjustStock('test_inv_sku_1', 20, 'POS Kasse #1 Verkauf', 'unit_test');
assert($adjustResult === true, "Stock adjustment should succeed");
$updatedArticle = InventoryManager::getArticle('test_inv_sku_1');
assert((int)$updatedArticle['stock'] === 20, "Stock should be 20");
echo "PASS: InventoryManager::adjustStock (new_stock 20)\n";

// Test stock adjustment below min_stock (triggers checkAndNotifyLowStock)
$lowStockResult = InventoryManager::adjustStock('test_inv_sku_1', 2, 'Meldebestand Test', 'unit_test');
assert($lowStockResult === true, "Stock adjustment below min_stock should succeed without crashing");
$lowArticle = InventoryManager::getArticle('test_inv_sku_1');
assert((int)$lowArticle['stock'] === 2, "Stock should be 2");
echo "PASS: InventoryManager::adjustStock with low stock alarm trigger\n";

// Test receiveStock
$receiveResult = InventoryManager::receiveStock('test_inv_sku_1', 10, 12.50, 'WE-TEST', 'Test Lieferant', 'Wareneingang Test', 'unit_test');
assert($receiveResult === true, "receiveStock should succeed");
$receivedArticle = InventoryManager::getArticle('test_inv_sku_1');
assert((int)$receivedArticle['stock'] === 12, "Stock should be 12 (2 + 10)");
echo "PASS: InventoryManager::receiveStock (+10 pieces)\n";

// Cleanup test article
InventoryManager::deleteArticle('test_inv_sku_1');
echo "PASS: Cleanup test article\n";

echo "\n============================================\n";
echo "ALL TESTS PASSED SUCCESSFULLY!\n";
echo "============================================\n";
