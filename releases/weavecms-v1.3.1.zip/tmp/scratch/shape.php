<?php
$d = json_decode(file_get_contents(__DIR__ . '/../data.sample.json'), true);
foreach ($d as $k => $v) {
    if (!is_array($v)) { echo "$k: scalar\n"; continue; }
    $isList = array_is_list($v);
    $first = $isList ? ($v[0] ?? null) : null;
    $desc = $isList ? ('list(' . count($v) . ') first=' . (is_array($first) ? 'array keys:' . implode(',', array_keys($first)) : gettype($first))) : 'map(' . count($v) . ') keys:' . implode(',', array_slice(array_keys($v), 0, 6)) . ' valtypes:' . implode(',', array_unique(array_map('gettype', $v)));
    echo "$k: $desc\n";
}
