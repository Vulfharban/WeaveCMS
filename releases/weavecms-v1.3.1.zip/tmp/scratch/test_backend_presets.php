<?php
require_once __DIR__ . '/../config.php';

echo "=== TEST 1: SectionManager Presets ===\n";
$presets = SectionManager::getPresets();
echo "Found " . count($presets) . " presets: " . implode(', ', array_keys($presets)) . "\n";
assert(count($presets) >= 6, "Expected at least 6 presets");

echo "\n=== TEST 2: Plugin Discovery ===\n";
$plugins = PluginManager::discover(true);
echo "Discovered plugins: " . implode(', ', array_keys($plugins)) . "\n";
assert(isset($plugins['weave-workshops']), "Expected weave-workshops plugin to be discovered");
assert(isset($plugins['weave-downloads']), "Expected weave-downloads plugin to be discovered");
echo "weave-workshops name: " . $plugins['weave-workshops']['name'] . "\n";
echo "weave-downloads name: " . $plugins['weave-downloads']['name'] . "\n";

echo "\n=== TEST 3: Apply Preset 'portfolio' ===\n";
$testData = [
    'settings' => [],
    'sections' => SectionManager::getDefaultSections()
];
$ok = SectionManager::applyPreset('portfolio', $testData);
assert($ok === true, "applyPreset failed");
assert($testData['settings']['project_preset'] === 'portfolio', "project_preset setting mismatch");

$visibleTypes = [];
foreach ($testData['sections'] as $sec) {
    if (!empty($sec['visible'])) {
        $visibleTypes[] = $sec['type'] ?? $sec['id'];
    }
}
echo "Visible sections in portfolio: " . implode(', ', $visibleTypes) . "\n";
assert(in_array('gallery', $visibleTypes, true), "gallery should be visible");
assert(!in_array('courses', $visibleTypes, true), "courses should NOT be visible in portfolio");
assert(!in_array('downloads', $visibleTypes, true), "downloads should NOT be visible in portfolio");

echo "\n=== TEST 4: Apply Preset 'workshops' ===\n";
$ok = SectionManager::applyPreset('workshops', $testData);
assert($ok === true, "applyPreset failed");
$visibleTypes = [];
foreach ($testData['sections'] as $sec) {
    if (!empty($sec['visible'])) {
        $visibleTypes[] = $sec['type'] ?? $sec['id'];
    }
}
echo "Visible sections in workshops: " . implode(', ', $visibleTypes) . "\n";
assert(in_array('courses', $visibleTypes, true), "courses SHOULD be visible in workshops");
assert(in_array('past_courses', $visibleTypes, true), "past_courses SHOULD be visible in workshops");
assert(!in_array('pricing', $visibleTypes, true), "pricing should NOT be visible in workshops");

echo "\n=== TEST 5: Apply Preset 'all' ===\n";
$ok = SectionManager::applyPreset('all', $testData);
assert($ok === true, "applyPreset failed");
$visibleTypes = [];
foreach ($testData['sections'] as $sec) {
    if (!empty($sec['visible'])) {
        $visibleTypes[] = $sec['type'] ?? $sec['id'];
    }
}
echo "Visible sections in all: " . implode(', ', $visibleTypes) . "\n";
assert(in_array('courses', $visibleTypes, true), "courses should be visible in all");
assert(in_array('gallery', $visibleTypes, true), "gallery should be visible in all");
assert(in_array('downloads', $visibleTypes, true), "downloads should be visible in all");

echo "\n✅ ALL UNIT TESTS PASSED SUCCESSFULLY!\n";
