<?php
/**
 * Test-Script für Phase 18: Flexible Website-Architektur & Modulare Landingpages
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../libs/php/MarkdownParser.php';
require_once __DIR__ . '/../libs/php/LanguageManager.php';
require_once __DIR__ . '/../libs/php/PluginManager.php';
require_once __DIR__ . '/../libs/php/SectionManager.php';
require_once __DIR__ . '/../libs/php/LogoRenderer.php';
require_once __DIR__ . '/../libs/php/StatsManager.php';
require_once __DIR__ . '/../libs/php/CaptchaManager.php';
require_once __DIR__ . '/../libs/php/FrontendController.php';

echo "=== STARTE TEST SUITE: PHASE 18 (Website-Architektur & Modulare Landingpages) ===\n\n";

$testData = [
    'settings' => [
        'site_architecture' => 'onepage',
        'primary_language' => 'de',
        'active_languages' => ['de', 'en']
    ],
    'texts' => [
        'hero_title' => 'WeaveCMS Test',
        'contact_name' => 'Test Meister'
    ],
    'sections' => SectionManager::getDefaultSections(),
    'pages' => [
        [
            'id' => 'p_standard',
            'title' => 'Standard Inhaltsseite',
            'slug' => 'standard-seite',
            'page_type' => 'content',
            'status' => 'published',
            'in_nav' => true,
            'content' => '# Hallo Welt\nDies ist eine Standardseite.'
        ],
        [
            'id' => 'p_modular',
            'title' => 'Aktions-Landingpage',
            'slug' => 'sommer-aktion',
            'page_type' => 'modular',
            'page_sections' => ['gallery', 'faq'],
            'status' => 'published',
            'in_nav' => true,
            'content' => '## Willkommen zu unserem Sommerspecial!'
        ]
    ]
];

// 1. Architektur-Modi
assert(SectionManager::getSiteArchitecture($testData) === 'onepage', 'Default Architektur ist onepage');
$testData['settings']['site_architecture'] = 'multipage';
assert(SectionManager::getSiteArchitecture($testData) === 'multipage', 'Architektur multipage erkannt');
$testData['settings']['site_architecture'] = 'hybrid';
assert(SectionManager::getSiteArchitecture($testData) === 'hybrid', 'Architektur hybrid erkannt');
$testData['settings']['site_architecture'] = 'invalid_val';
assert(SectionManager::getSiteArchitecture($testData) === 'onepage', 'Ungültige Architektur fällt auf onepage zurück');
echo "✓ 1. getSiteArchitecture() funktioniert einwandfrei.\n";

// 2. ensureSections & Placements
$testData['settings']['site_architecture'] = 'onepage';
$sections = SectionManager::ensureSections($testData);
assert(!empty($sections), 'ensureSections liefert Sektionen');
$hero = SectionManager::getSectionById('hero', $testData);
assert($hero && $hero['placement'] === 'home', 'Hero hat Standard-Placement home');
$gallery = SectionManager::getSectionById('gallery', $testData);
assert($gallery && $gallery['placement'] === 'both', 'Galerie hat Standard-Placement both');
echo "✓ 2. ensureSections() & Standard-Placements validiert.\n";

// 3. getSectionsForHomePage() in verschiedenen Modi
// A) onepage
$testData['settings']['site_architecture'] = 'onepage';
$homeSecs = SectionManager::getSectionsForHomePage($testData);
assert(count($homeSecs) === count(SectionManager::getVisibleSections($testData)), 'Onepage zeigt alle sichtbaren Sektionen auf Home');

// B) multipage
$testData['settings']['site_architecture'] = 'multipage';
$homeSecsMulti = SectionManager::getSectionsForHomePage($testData);
$homeSecIds = array_column($homeSecsMulti, 'id');
assert(in_array('hero', $homeSecIds, true), 'Multi-Page zeigt Hero auf Home');
assert(!in_array('gallery', $homeSecIds, true), 'Multi-Page zeigt Galerie NICHT auf Home (läuft als Einzelseite)');
assert(!in_array('courses', $homeSecIds, true), 'Multi-Page zeigt Kurse NICHT auf Home (läuft als Einzelseite)');

// C) hybrid
$testData['settings']['site_architecture'] = 'hybrid';
SectionManager::updateSection($testData, 'gallery', ['placement' => 'page']);
SectionManager::updateSection($testData, 'pricing', ['placement' => 'home']);
$homeSecsHybrid = SectionManager::getSectionsForHomePage($testData);
$hybridSecIds = array_column($homeSecsHybrid, 'id');
assert(!in_array('gallery', $hybridSecIds, true), 'Hybrid blendet placement=page auf Home aus');
assert(in_array('pricing', $hybridSecIds, true), 'Hybrid zeigt placement=home auf Home an');
echo "✓ 3. getSectionsForHomePage() für onepage, multipage & hybrid korrekt.\n";

// 4. getNavItems() Link-Generierung
// In multipage mode
$testData['settings']['site_architecture'] = 'multipage';
$navItems = SectionManager::getNavItems($testData);
$navBySec = [];
foreach ($navItems as $item) {
    $navBySec[$item['id']] = $item;
}
assert(isset($navBySec['gallery']['url']) && strpos($navBySec['gallery']['url'], '?page=gallery') !== false, 'Galerie-Menülink führt auf ?page=gallery in Multi-Page');
assert(isset($navBySec['courses']['url']) && strpos($navBySec['courses']['url'], '?page=courses') !== false, 'Kurse-Menülink führt auf ?page=courses in Multi-Page');
assert(isset($navBySec['page-sommer-aktion']['url']) && strpos($navBySec['page-sommer-aktion']['url'], '?page=sommer-aktion') !== false, 'Modulare Seite ist im Menü verlinkt');
echo "✓ 4. getNavItems() generiert saubere Multi-Page & Modular-Links.\n";

// 5. FrontendController Rendering
// Test A: Modulare Landingpage Rendering (?page=sommer-aktion)
$_GET = ['page' => 'sommer-aktion'];
ob_start();
FrontendController::renderPage($testData);
$outModular = ob_get_clean();
assert(strpos($outModular, 'modular-page-wrapper') !== false, 'Modulare Seite rendert modular-page-wrapper');
assert(strpos($outModular, 'Sommerspecial') !== false, 'Modulare Seite rendert Einleitungstext');
assert(strpos($outModular, 'section-gallery') !== false || strpos($outModular, 'id="gallery"') !== false, 'Modulare Seite rendert Galerie-Sektion');
assert(strpos($outModular, 'section-faq') !== false || strpos($outModular, 'id="faq"') !== false, 'Modulare Seite rendert FAQ-Sektion');
echo "✓ 5. FrontendController rendert Modulare Landingpage fehlerfrei.\n";

// Test B: Standalone Section Rendering (?page=gallery)
$_GET = ['page' => 'gallery'];
ob_start();
FrontendController::renderPage($testData);
$outStandalone = ob_get_clean();
assert(strpos($outStandalone, 'standalone-section-wrapper') !== false, 'Standalone Sektion rendert standalone-section-wrapper');
assert(strpos($outStandalone, 'id="gallery"') !== false, 'Standalone Sektion rendert die Galerie');
echo "✓ 6. FrontendController rendert Standalone-Sektion fehlerfrei.\n";

// Test C: Startseite im Multi-Page Modus
$_GET = [];
$testData['settings']['site_architecture'] = 'multipage';
ob_start();
FrontendController::renderPage($testData);
$outHomeMulti = ob_get_clean();
assert(strpos($outHomeMulti, 'id="hero"') !== false, 'Startseite im Multi-Page Modus rendert Hero');
assert(strpos($outHomeMulti, 'id="courses"') === false, 'Startseite im Multi-Page Modus rendert keine Kurse-Sektion im Main');
echo "✓ 7. FrontendController rendert kompakte Multi-Page Startseite fehlerfrei.\n";

echo "\n=======================================================\n";
echo "🎉 ALLE 7 TEST-BEREICHE VON PHASE 18 ERFOLGREICH BESTANDEN!\n";
echo "=======================================================\n";
