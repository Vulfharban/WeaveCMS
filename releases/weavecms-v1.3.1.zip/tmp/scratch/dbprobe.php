<?php
require __DIR__ . '/../libs/php/storage/StorageManager.php';
StorageManager::testDbConnection(['host'=>'127.0.0.1','database'=>'weave_probe_test','username'=>'root','password'=>'','create_db'=>true]);
$d = new PdoSqlStorageDriver(['host'=>'127.0.0.1','database'=>'weave_probe_test','username'=>'root','password'=>'','prefix'=>'weave_']);
$data = json_decode(file_get_contents(__DIR__ . '/../data.sample.json'), true);
$data['plugin_x'] = ['a' => 1];
$data['past_courses'] = [];   // bewusst leer
unset($data['team']);          // fehlt komplett
var_dump($d->saveData($data), $d->getLastError());
$back = $d->loadData();
foreach ($data as $k => $v) if (json_encode($back[$k] ?? null) !== json_encode($v)) echo "DIFF: $k\n";
foreach (array_diff(array_keys($back), array_keys($data)) as $k) echo "EXTRA: $k\n";
echo "team present: ", var_export(array_key_exists('team', $back), true), " | past_courses: ", json_encode($back['past_courses']), "\n";
// Bereich wieder befüllen -> Marker muss verschwinden
$data['past_courses'] = ['x'];
$d->saveData($data);
echo json_encode($d->loadData()['past_courses']), "\n";
$p = new PDO('mysql:host=127.0.0.1', 'root', '');
$p->exec('DROP DATABASE IF EXISTS weave_probe_test');
