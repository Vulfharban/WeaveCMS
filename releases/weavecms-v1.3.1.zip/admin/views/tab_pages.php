<?php
/**
 * WeaveCMS – Admin Tab: Freie Einzelseiten (Custom Subpages)
 * 
 * Ermöglicht das Anlegen und Verwalten eigenständiger Inhaltsseiten
 * (z. B. Über die Werkstatt, Anfahrt & Parken, Nachhaltigkeit) mit
 * Markdown-Formatierung, eigenem Slug, Menü-Verknüpfung und Mehrsprachigkeit.
 * 
 * @var array $data Gesamtdatenstruktur
 * @var string $csrf_token CSRF-Schutztoken
 */

$pages = $data['pages'] ?? [];
$total_pages = count($pages);
$published_pages = 0;
$in_nav_count = 0;
foreach ($pages as $pg) {
    if (($pg['status'] ?? 'published') === 'published') {
        $published_pages++;
    }
    if (!empty($pg['in_nav'])) {
        $in_nav_count++;
    }
}

$active_langs = LanguageManager::getActiveLanguages($data);
$primary_lang = LanguageManager::getPrimaryLanguage($data);
$supported_langs = LanguageManager::getSupportedLanguages();
?>
        <!-- ──────────────── SECTION PAGES: FREIE EINZELSEITEN ──────────────── -->
        <div id="tab-pages" class="admin-section card" style="padding: 2.5rem;">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:1rem; margin-bottom: 1.5rem;">
                <div>
                    <h2 style="color: var(--primary); margin-bottom: 0.5rem; display:flex; align-items:center; gap:8px;">
                        <span class="material-icons" style="font-size:28px;">article</span> <?php echo __a('admin.pages.title'); ?>
                    </h2>
                    <p style="color: var(--text-secondary); font-size: 0.95rem; margin:0;">
                        <?php echo __a('admin.pages.subtitle'); ?>
                    </p>
                </div>
                <div style="display:flex; align-items:center; gap:12px;">
                    <button type="button" class="btn btn-primary" onclick="openPageEditor()">
                        <span class="material-icons" style="font-size:18px;">add_circle</span> <?php echo __a('admin.pages.btn_new'); ?>
                    </button>
                </div>
            </div>

            <!-- Kennzahlen-Karten -->
            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
                <div style="background: rgba(255,255,255,0.03); border:1px solid var(--border-color); border-radius:12px; padding: 1rem 1.25rem;">
                    <div style="font-size: 0.8rem; color: var(--text-secondary); text-transform:uppercase; letter-spacing:0.5px; font-weight:700;"><?php echo __a('admin.pages.kpi_total'); ?></div>
                    <div style="font-size: 1.8rem; font-weight: 800; color: var(--text-primary); margin-top:4px;"><?php echo $total_pages; ?></div>
                </div>
                <div style="background: rgba(16, 185, 129, 0.05); border:1px solid rgba(16, 185, 129, 0.3); border-radius:12px; padding: 1rem 1.25rem;">
                    <div style="font-size: 0.8rem; color: #10b981; text-transform:uppercase; letter-spacing:0.5px; font-weight:700;"><?php echo __a('admin.pages.kpi_published'); ?></div>
                    <div style="font-size: 1.8rem; font-weight: 800; color: #10b981; margin-top:4px;"><?php echo $published_pages; ?></div>
                </div>
                <div style="background: rgba(59, 130, 246, 0.05); border:1px solid rgba(59, 130, 246, 0.3); border-radius:12px; padding: 1rem 1.25rem;">
                    <div style="font-size: 0.8rem; color: #3b82f6; text-transform:uppercase; letter-spacing:0.5px; font-weight:700;"><?php echo __a('admin.pages.kpi_in_nav'); ?></div>
                    <div style="font-size: 1.8rem; font-weight: 800; color: #3b82f6; margin-top:4px;"><?php echo $in_nav_count; ?></div>
                </div>
            </div>

            <!-- ──────────────── FORMULAR / EDITOR DRAWER ──────────────── -->
            <style>
                .page-editor-sticky-bar {
                    position: sticky;
                    top: 192px;
                    z-index: 480;
                    background: rgba(251, 249, 246, 0.96);
                    backdrop-filter: blur(14px);
                    -webkit-backdrop-filter: blur(14px);
                    border: 1px solid var(--border-color);
                    border-radius: 14px;
                    padding: 8px 14px;
                    margin-bottom: 1.5rem;
                    box-shadow: 0 4px 18px rgba(0, 0, 0, 0.06);
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    gap: 12px;
                    flex-wrap: wrap;
                    transition: box-shadow 0.2s ease, top 0.2s ease;
                }
                [data-theme="dark"] .page-editor-sticky-bar {
                    background: rgba(26, 32, 44, 0.96);
                    border-color: rgba(255, 255, 255, 0.12);
                    box-shadow: 0 6px 22px rgba(0, 0, 0, 0.35);
                }
                .sticky-lang-pill {
                    transition: all 0.15s ease;
                }
                .sticky-lang-pill:hover {
                    transform: translateY(-1px);
                }
                .sticky-status-dot {
                    transition: background-color 0.2s ease;
                }
            </style>

            <div id="page-editor-box" style="display:none; scroll-margin-top: 150px; background:rgba(255,255,255,0.02); border:1px solid var(--primary); border-radius:16px; padding:2rem; margin-bottom:2.5rem; animation: fadeInTab 0.25s ease;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; border-bottom:1px solid var(--border-color); padding-bottom:0.75rem;">
                    <h3 id="page-editor-title" style="color:var(--primary); margin:0; display:flex; align-items:center; gap:8px;">
                        <span class="material-icons">edit_note</span> <?php echo __a('admin.pages.new_page'); ?>
                    </h3>
                    <button type="button" class="btn btn-secondary" onclick="closePageEditor()" style="padding:4px 10px; font-size:0.8rem;">
                        <span class="material-icons" style="font-size:16px;">close</span> <?php echo __a('admin.pages.drawer_close'); ?>
                    </button>
                </div>

                <form method="POST" action="" id="page-form">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                    <input type="hidden" name="action" id="page_form_action" value="add_page">
                    <input type="hidden" name="target_tab" value="tab-pages">
                    <input type="hidden" name="id" id="page_id" value="">

                    <!-- ──────────────── SCHWEBENDE / STICKY TOOLBAR ──────────────── -->
                    <div id="page-editor-sticky-bar" class="page-editor-sticky-bar">
                        <!-- 1. Seitenwechsler Dropdown -->
                        <div style="display:flex; align-items:center; gap:8px; flex-shrink:0;">
                            <span class="material-icons" style="font-size:18px; color:var(--primary);">menu_book</span>
                            <label for="sticky_page_selector" style="font-size:0.8rem; font-weight:700; color:var(--text-secondary); margin:0; text-transform:uppercase; letter-spacing:0.5px;"><?php echo __a('admin.pages.page_switcher'); ?></label>
                            <select id="sticky_page_selector" onchange="onStickyPageSelect(this.value)" class="form-control" style="font-size:0.85rem; padding:4px 8px; width:auto; max-width:210px; font-weight:600; cursor:pointer; height:auto; border-radius:8px;">
                                <option value=""><?php echo __a('admin.pages.new_page_option'); ?></option>
                                <?php foreach ($pages as $p): ?>
                                    <option value="<?php echo htmlspecialchars($p['id'] ?? ''); ?>">
                                        <?php echo htmlspecialchars($p['title'] ?? 'Unbenannt'); ?> (<?php echo htmlspecialchars($p['slug'] ?? ''); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- 2. Schwebende Sprach-Pills mit Statusanzeige -->
                        <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap; flex:1; justify-content:center; min-width:220px;">
                            <span style="font-size:0.8rem; font-weight:700; color:var(--text-secondary); display:inline-flex; align-items:center; gap:4px; margin-right:4px;">
                                <span class="material-icons" style="font-size:15px;">translate</span> <?php echo __a('admin.pages.sticky_lang'); ?>
                            </span>
                            <button type="button" class="btn btn-primary sticky-lang-pill" id="sticky-lang-btn-<?php echo $primary_lang; ?>" onclick="switchPageLangTab('<?php echo $primary_lang; ?>')" style="padding:4px 10px; font-size:0.82rem; display:inline-flex; align-items:center; gap:6px; border-radius:20px;">
                                <span><?php echo $supported_langs[$primary_lang]['flag']; ?></span>
                                <span><?php echo strtoupper($primary_lang); ?></span>
                                <span class="sticky-status-dot" id="sticky-dot-<?php echo $primary_lang; ?>" title="<?php echo htmlspecialchars(__a('admin.pages.status_dot_ok')); ?>" style="width:7px; height:7px; border-radius:50%; background:#10b981; display:inline-block;"></span>
                            </button>
                            <?php if (count($active_langs) > 1): ?>
                                <?php foreach ($active_langs as $al): if ($al === $primary_lang) continue; ?>
                                    <button type="button" class="btn btn-outline sticky-lang-pill" id="sticky-lang-btn-<?php echo $al; ?>" onclick="switchPageLangTab('<?php echo $al; ?>')" style="padding:4px 10px; font-size:0.82rem; display:inline-flex; align-items:center; gap:6px; border-radius:20px;">
                                        <span><?php echo $supported_langs[$al]['flag']; ?></span>
                                        <span><?php echo strtoupper($al); ?></span>
                                        <span class="sticky-status-dot" id="sticky-dot-<?php echo $al; ?>" title="<?php echo htmlspecialchars(__a('admin.pages.status_dot_empty')); ?>" style="width:7px; height:7px; border-radius:50%; background:#94a3b8; display:inline-block;"></span>
                                    </button>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>

                        <!-- 3. Schnell-Aktionen (Schnell-Speichern & Schließen) -->
                        <div style="display:flex; align-items:center; gap:8px; flex-shrink:0;">
                            <button type="button" class="btn btn-primary" onclick="submitPageFormQuick()" style="padding:5px 12px; font-size:0.84rem; display:inline-flex; align-items:center; gap:6px; border-radius:8px;" title="<?php echo htmlspecialchars(__a('admin.pages.sticky_quick_save_title')); ?>">
                                <span class="material-icons" style="font-size:16px;">save</span> <?php echo __a('admin.pages.quick_save'); ?>
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="closePageEditor()" style="padding:5px 10px; font-size:0.84rem; display:inline-flex; align-items:center; border-radius:8px;" title="<?php echo htmlspecialchars(__a('admin.pages.drawer_close')); ?>">
                                <span class="material-icons" style="font-size:16px;">close</span>
                            </button>
                        </div>
                    </div>

                    <!-- Gemeinsame Einstellungen: Status, Seitentyp, Hauptmenü-Einbindung, Basis-Slug, Icon -->
                    <div class="grid-5" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; background:rgba(255,255,255,0.02); padding:1rem; border-radius:10px; border:1px solid var(--border-color);">
                        <div class="form-group">
                            <label for="page_slug" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;">
                                <?php echo __a('admin.pages.field_slug'); ?>
                                <span style="font-size:0.8rem; font-weight:normal; color:var(--text-secondary);">(z. B. aktion)</span>
                            </label>
                            <input type="text" id="page_slug" name="slug" class="form-control" placeholder="aktion" required pattern="[a-z0-9_-]+">
                        </div>
                        <div class="form-group">
                            <label for="page_type" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;"><?php echo __a('admin.pages.field_type'); ?></label>
                            <select id="page_type" name="page_type" class="form-control" onchange="togglePageTypeMode(this.value)">
                                <option value="content"><?php echo __a('admin.pages.type_content'); ?></option>
                                <option value="modular"><?php echo __a('admin.pages.type_modular'); ?></option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="page_status" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;"><?php echo __a('admin.pages.field_status'); ?></label>
                            <select id="page_status" name="status" class="form-control" onchange="togglePageScheduledBox(this.value)">
                                <option value="published"><?php echo __a('admin.pages.status_published'); ?></option>
                                <option value="draft"><?php echo __a('admin.pages.status_draft'); ?></option>
                                <option value="scheduled"><?php echo __a('admin.pages.status_scheduled'); ?></option>
                            </select>
                            <div id="page_scheduled_box" style="display:none; margin-top:8px;">
                                <label for="page_publish_at" style="font-size:0.78rem; font-weight:700; color:var(--text-secondary); display:block; margin-bottom:2px;"><?php echo __a('admin.pages.field_publish_at'); ?></label>
                                <input type="datetime-local" id="page_publish_at" name="publish_at" class="form-control" style="font-size:0.85rem; padding:4px 8px;">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="page_icon" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;">
                                <?php echo __a('admin.pages.field_icon'); ?>
                            </label>
                            <div style="display:flex; align-items:center; gap:6px;">
                                <input type="text" id="page_icon" name="icon" class="form-control" placeholder="article" oninput="updatePageIconPreview(this.value)">
                                <span id="page_icon_preview" class="material-icons" style="font-size:22px; color:var(--primary); min-width:28px; text-align:center;">article</span>
                            </div>
                        </div>
                        <div class="form-group" style="display:flex; flex-direction:column; justify-content:center;">
                            <label style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;"><?php echo __a('admin.pages.field_in_nav'); ?></label>
                            <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:0.95rem; margin-top:6px;">
                                <input type="checkbox" id="page_in_nav" name="in_nav" value="1">
                                <span><?php echo __a('admin.pages.in_nav_checkbox'); ?></span>
                            </label>
                        </div>
                    </div>

                    <!-- Modulare Sektionen-Auswahl (Landingpage-Stack) -->
                    <div id="modular-sections-box" style="display:none; background:rgba(46,98,72,0.06); border:1px solid rgba(46,98,72,0.3); border-radius:12px; padding:1.25rem; margin-bottom:1.5rem;">
                        <h4 style="color:var(--primary); margin:0 0 0.4rem 0; font-size:1.05rem; display:flex; align-items:center; gap:6px;">
                            <span class="material-icons">view_quilt</span> <?php echo __a('admin.pages.modular_heading'); ?>
                        </h4>
                        <p style="color:var(--text-secondary); font-size:0.85rem; margin:0 0 1rem 0;">
                            <?php echo __a('admin.pages.modular_desc'); ?>
                        </p>
                        <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap:10px;">
                            <?php 
                            $avail_sections = SectionManager::ensureSections($data);
                            $sec_type_icons = [
                                'hero' => 'flag', 'gallery' => 'photo_library', 'courses' => 'event',
                                'past_courses' => 'photo_camera', 'blog' => 'newspaper', 'about' => 'badge',
                                'custom_text' => 'article', 'pricing' => 'sell', 'faq' => 'quiz',
                                'team' => 'groups', 'downloads' => 'file_download', 'webtrees' => 'account_tree', 'shop' => 'storefront'
                            ];
                            foreach ($avail_sections as $asec):
                                $aicon = $sec_type_icons[$asec['type']] ?? 'dashboard';
                            ?>
                                <label style="display:flex; align-items:center; gap:8px; padding:8px 12px; background:#ffffff; border:1px solid var(--border-color); border-radius:10px; cursor:pointer; font-size:0.9rem;">
                                    <input type="checkbox" name="page_sections[]" value="<?php echo htmlspecialchars($asec['id']); ?>" class="modular-sec-checkbox" style="width:16px; height:16px; accent-color:var(--primary);">
                                    <span class="material-icons" style="font-size:18px; color:var(--primary);"><?php echo $aicon; ?></span>
                                    <span style="font-weight:600; color:var(--text-primary);"><?php echo htmlspecialchars($asec['title']); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Panel: Hauptsprache -->
                    <div id="page-lang-panel-<?php echo $primary_lang; ?>" class="page-lang-panel">
                        <div class="grid-2" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; margin-bottom: 1.25rem;">
                            <div class="form-group">
                                <label for="page_title" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;">
                                    <?php echo str_replace('{lang}', htmlspecialchars($supported_langs[$primary_lang]['name']), __a('admin.pages.field_title')); ?> *
                                </label>
                                <input type="text" id="page_title" name="title" class="form-control" placeholder="<?php echo htmlspecialchars(__a('admin.pages.placeholder_title')); ?>" required oninput="autoGeneratePageSlug(this.value)">
                            </div>
                            <div class="form-group">
                                <label for="page_nav_label" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;">
                                    <?php echo __a('admin.pages.field_nav_label'); ?>
                                </label>
                                <input type="text" id="page_nav_label" name="nav_label" class="form-control" placeholder="<?php echo htmlspecialchars(__a('admin.pages.placeholder_nav_label')); ?>">
                            </div>
                        </div>

                        <div class="form-group" style="margin-bottom: 1.25rem;">
                            <label for="page_meta_desc" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;">
                                <?php echo __a('admin.pages.field_meta_desc'); ?>
                            </label>
                            <input type="text" id="page_meta_desc" name="meta_description" class="form-control" placeholder="<?php echo htmlspecialchars(__a('admin.pages.placeholder_meta_desc')); ?>">
                        </div>

                        <div class="form-group" style="margin-bottom: 1.5rem;">
                            <label for="page_content" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:flex; justify-content:space-between; align-items:center;">
                                <span><?php echo __a('admin.pages.field_content'); ?> *</span>
                                <span style="font-size:0.8rem; font-weight:normal; color:var(--text-secondary);"><?php echo __a('admin.pages.content_hint'); ?></span>
                            </label>

                            <!-- Design- & Layout-Toolbar für Einzelseiten -->
                            <div class="page-editor-design-toolbar" style="background:rgba(255,255,255,0.03); border:1px solid var(--border-color); border-radius:10px; padding:10px 14px; margin-bottom:0.75rem; display:flex; align-items:center; flex-wrap:wrap; gap:10px;">
                                <span style="font-size:0.85rem; font-weight:700; color:var(--primary); display:inline-flex; align-items:center; gap:5px;">
                                    <span class="material-icons" style="font-size:18px;">auto_awesome</span> <?php echo __a('admin.pages.toolbar_template'); ?>
                                </span>

                                <!-- Überschriften-Stile -->
                                <select onchange="insertPageSnippet(this, 'heading')" class="form-control" style="width:auto; padding:5px 10px; font-size:0.83rem; border-radius:8px; cursor:pointer;" title="Vordefinierte Überschriftarten">
                                    <option value=""><?php echo __a('admin.pages.toolbar_heading_style'); ?></option>
                                    <option value="left_bar">Akzent-Balken links</option>
                                    <option value="underline">Farbverlauf-Unterstrich</option>
                                    <option value="eyebrow">Eyebrow / Kicker-Badge</option>
                                    <option value="gradient">Gradient-Farbverlauf</option>
                                    <option value="icon">Icon-Überschrift (✨)</option>
                                    <option value="display">Großer Display / Hero-Titel</option>
                                </select>

                                <!-- Einfärbbare Div-Boxen -->
                                <select onchange="insertPageSnippet(this, 'box')" class="form-control" style="width:auto; padding:5px 10px; font-size:0.83rem; border-radius:8px; cursor:pointer;" title="Einfärbbare Boxen & Cards">
                                    <option value=""><?php echo __a('admin.pages.toolbar_box_style'); ?></option>
                                    <option value="soft_primary">Sanfte Primär-Box (Theme)</option>
                                    <option value="soft_success">Sanfte Smaragd/Erfolgs-Box</option>
                                    <option value="soft_amber">Sanfte Bernstein/Warn-Box</option>
                                    <option value="soft_purple">Sanfte Violett/Kreativ-Box</option>
                                    <option value="gradient">Farbverlauf-Box (Gradient)</option>
                                    <option value="dark">Dark / Glassmorphism-Card</option>
                                    <option value="tintable">Frei einfärbbare Box (Farbwähler)</option>
                                </select>

                                <!-- Farbwähler für Box-Hintergrund -->
                                <label title="Wunschfarbe für frei einfärbbare Box wählen" style="display:inline-flex; align-items:center; gap:4px; font-size:0.8rem; color:var(--text-secondary); cursor:pointer;">
                                    <input type="color" id="picker_box_color" value="#e0f2fe" style="width:26px; height:26px; border:none; border-radius:6px; cursor:pointer; padding:0; background:none;">
                                    <span><?php echo __a('admin.pages.toolbar_color_label'); ?></span>
                                </label>

                                <!-- Optische Trenner -->
                                <select onchange="insertPageSnippet(this, 'divider')" class="form-control" style="width:auto; padding:5px 10px; font-size:0.83rem; border-radius:8px; cursor:pointer;" title="Optische Trenner">
                                    <option value=""><?php echo __a('admin.pages.toolbar_divider_style'); ?></option>
                                    <option value="gradient">Farbverlauf-Linie</option>
                                    <option value="icon_leaf">Trennlinie mit Blatt (🌿)</option>
                                    <option value="icon_star">Trennlinie mit Stern (⭐)</option>
                                    <option value="glow">Leuchtende Glow-Linie</option>
                                    <option value="dots">Gepunkteter Trenner</option>
                                    <option value="dashed">Gestrichelter Trenner</option>
                                    <option value="wave">Wellen-Trennlinie</option>
                                </select>
                            </div>

                            <textarea id="page_content" name="content" class="form-control" rows="12" placeholder="Schreibe hier den vollständigen Text deiner Seite..." required style="font-family: monospace; font-size:0.95rem; line-height:1.6;"></textarea>
                        </div>
                    </div>

                    <!-- Panels für weitere aktive Sprachen -->
                    <?php foreach ($active_langs as $al): if ($al === $primary_lang) continue; ?>
                        <div id="page-lang-panel-<?php echo $al; ?>" class="page-lang-panel" style="display:none;">
                            <div style="background:rgba(59, 130, 246, 0.08); border:1px solid #3b82f6; border-radius:10px; padding:10px 14px; margin-bottom:1.25rem; font-size:0.88rem; color:#93c5fd; display:flex; align-items:center; gap:8px;">
                                <span class="material-icons" style="font-size:18px; color:#60a5fa;">translate</span>
                                <span><?php echo str_replace(['{lang}', '{primary}'], ['<strong>' . $supported_langs[$al]['flag'] . ' ' . htmlspecialchars($supported_langs[$al]['name']) . '</strong>', htmlspecialchars($supported_langs[$primary_lang]['name'])], __a('admin.pages.trans_info')); ?></span>
                            </div>

                            <div class="grid-2" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; margin-bottom: 1.25rem;">
                                <div class="form-group">
                                    <label for="trans_<?php echo $al; ?>_title" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;">
                                        <?php echo str_replace('{lang}', htmlspecialchars($supported_langs[$al]['name']), __a('admin.pages.field_title')); ?>
                                    </label>
                                    <input type="text" id="trans_<?php echo $al; ?>_title" name="trans_<?php echo $al; ?>_title" class="form-control" placeholder="Titel auf <?php echo htmlspecialchars($supported_langs[$al]['name']); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="trans_<?php echo $al; ?>_nav_label" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;">
                                        <?php echo __a('admin.pages.field_nav_label'); ?>
                                    </label>
                                    <input type="text" id="trans_<?php echo $al; ?>_nav_label" name="trans_<?php echo $al; ?>_nav_label" class="form-control" placeholder="Menü-Titel auf <?php echo htmlspecialchars($supported_langs[$al]['name']); ?>">
                                </div>
                            </div>

                            <div class="form-group" style="margin-bottom: 1.25rem;">
                                <label for="trans_<?php echo $al; ?>_meta_desc" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:block;">
                                    <?php echo __a('admin.pages.field_meta_desc'); ?>
                                </label>
                                <input type="text" id="trans_<?php echo $al; ?>_meta_desc" name="trans_<?php echo $al; ?>_meta_description" class="form-control" placeholder="SEO-Beschreibung auf <?php echo htmlspecialchars($supported_langs[$al]['name']); ?>">
                            </div>

                            <div class="form-group" style="margin-bottom: 1.5rem;">
                                <label for="trans_<?php echo $al; ?>_content" style="font-weight:700; color:var(--text-primary); margin-bottom:0.4rem; display:flex; justify-content:space-between; align-items:center;">
                                    <span><?php echo __a('admin.pages.field_content'); ?> (<?php echo htmlspecialchars($supported_langs[$al]['name']); ?>)</span>
                                </label>
                                <textarea id="trans_<?php echo $al; ?>_content" name="trans_<?php echo $al; ?>_content" class="form-control" rows="12" placeholder="Übersetzter Markdown-Inhalt..." style="font-family: monospace; font-size:0.95rem; line-height:1.6;"></textarea>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <div class="form-group" style="margin-bottom: 1.25rem; background:rgba(255,255,255,0.02); border:1px solid var(--border-color); padding:0.75rem 1rem; border-radius:10px;">
                        <label for="page_revision_note" style="font-weight:600; font-size:0.85rem; color:var(--text-secondary); display:block; margin-bottom:0.25rem;">
                            <span class="material-icons" style="font-size:15px; vertical-align:middle;">history_edu</span> <?php echo __a('admin.pages.field_revision_note'); ?>
                        </label>
                        <input type="text" id="page_revision_note" name="revision_note" class="form-control" placeholder="<?php echo htmlspecialchars(__a('admin.pages.placeholder_revision')); ?>" style="font-size:0.85rem;">
                    </div>

                    <div style="display:flex; justify-content:flex-end; gap:12px;">
                        <button type="button" class="btn btn-secondary" onclick="closePageEditor()"><?php echo __a('admin.pages.btn_cancel'); ?></button>
                        <button type="submit" class="btn btn-primary" id="page-submit-btn">
                            <span class="material-icons" style="font-size:18px;">save</span> <?php echo __a('admin.pages.btn_save'); ?>
                        </button>
                    </div>
                </form>
            </div>

            <!-- ──────────────── SEITEN-LISTE / TABELLE ──────────────── -->
            <?php if (empty($pages)): ?>
                <div style="text-align:center; padding: 3rem 1.5rem; background:rgba(255,255,255,0.02); border:1px dashed var(--border-color); border-radius:14px;">
                    <span class="material-icons" style="font-size:48px; color:var(--text-secondary); margin-bottom:0.5rem; opacity:0.6;">article</span>
                    <h3 style="margin:0 0 0.5rem 0; color:var(--text-primary);"><?php echo __a('admin.pages.empty_title'); ?></h3>
                    <p style="color:var(--text-secondary); font-size:0.95rem; margin-bottom:1.5rem;"><?php echo __a('admin.pages.empty_desc'); ?></p>
                    <button type="button" class="btn btn-primary" onclick="openPageEditor()">
                        <span class="material-icons" style="font-size:18px;">add_circle</span> <?php echo __a('admin.pages.empty_btn'); ?>
                    </button>
                </div>
            <?php else: ?>
                <div style="display:flex; flex-direction:column; gap:0.75rem;">
                    <?php foreach ($pages as $p): ?>
                        <?php 
                            $p_status = $p['status'] ?? 'published';
                            $p_publish_at = $p['publish_at'] ?? '';
                            $p_token = $p['preview_token'] ?? '';
                            $p_slug = $p['slug'] ?? '';
                            $p_url = '../?page=' . urlencode($p_slug);
                            $p_preview_url = '../?page=' . urlencode($p_slug) . ($p_token ? '&preview=' . urlencode($p_token) : '');
                            $p_nav = !empty($p['nav_label']) ? $p['nav_label'] : ($p['title'] ?? '');
                        ?>
                        <div class="card" style="padding:1.25rem 1.5rem; border-radius:12px; display:flex; justify-content:space-between; align-items:center; gap:1rem; flex-wrap:wrap;">
                            <div style="display:flex; align-items:center; gap:1rem; flex:1; min-width:280px;">
                                <div style="width:42px; height:42px; border-radius:8px; background:rgba(46,98,72,0.1); color:var(--primary); display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                                    <span class="material-icons"><?php echo htmlspecialchars(!empty($p['icon']) ? $p['icon'] : 'article'); ?></span>
                                </div>
                                <div>
                                    <h4 style="margin:0 0 4px 0; font-size:1.05rem; color:var(--text-primary); display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                                        <span><?php echo htmlspecialchars($p['title'] ?? 'Unbenannt'); ?></span>
                                        <?php 
                                            $is_modular = ($p['page_type'] ?? 'content') === 'modular';
                                            $sec_count = count($p['page_sections'] ?? []);
                                        ?>
                                        <?php if ($is_modular): ?>
                                            <span style="font-size:0.7rem; font-weight:700; color:#8b5cf6; background:rgba(139,92,246,0.1); padding:2px 8px; border-radius:999px;">
                                                <?php echo str_replace('{count}', $sec_count, __a('admin.pages.badge_modular')); ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="font-size:0.7rem; font-weight:600; color:var(--text-secondary); background:rgba(255,255,255,0.06); padding:2px 8px; border-radius:999px;">
                                                <?php echo __a('admin.pages.badge_standard'); ?>
                                            </span>
                                        <?php endif; ?>
                                        <?php if ($p_status === 'published'): ?>
                                            <span style="font-size:0.7rem; font-weight:700; color:#10b981; background:rgba(16,185,129,0.1); padding:2px 8px; border-radius:999px;"><?php echo __a('admin.pages.badge_published'); ?></span>
                                        <?php elseif ($p_status === 'scheduled'): ?>
                                            <span style="font-size:0.7rem; font-weight:700; color:#3b82f6; background:rgba(59,130,246,0.1); padding:2px 8px; border-radius:999px;" title="<?php echo htmlspecialchars(str_replace('{date}', $p_publish_at, __a('admin.pages.badge_scheduled'))); ?>">
                                                ⏱️ <?php echo htmlspecialchars(str_replace('{date}', date('d.m.Y H:i', strtotime($p_publish_at ?: 'now')), __a('admin.pages.badge_scheduled'))); ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="font-size:0.7rem; font-weight:700; color:#f59e0b; background:rgba(245,158,11,0.1); padding:2px 8px; border-radius:999px;"><?php echo __a('admin.pages.badge_draft'); ?></span>
                                        <?php endif; ?>
                                        <?php if (!empty($p['in_nav'])): ?>
                                            <span style="font-size:0.7rem; font-weight:700; color:#3b82f6; background:rgba(59,130,246,0.1); padding:2px 8px; border-radius:999px;" title="Titel im Menü: <?php echo htmlspecialchars($p_nav); ?>">
                                                <?php echo str_replace('{label}', '<strong>' . htmlspecialchars($p_nav) . '</strong>', __a('admin.pages.badge_in_nav')); ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="font-size:0.7rem; color:var(--text-secondary); background:rgba(255,255,255,0.05); padding:2px 8px; border-radius:999px;"><?php echo __a('admin.pages.badge_not_in_nav'); ?></span>
                                        <?php endif; ?>
                                    </h4>
                                    
                                    <div style="font-size:0.85rem; color:var(--text-secondary); display:flex; gap:14px; flex-wrap:wrap; align-items:center; margin-top:4px;">
                                        <span><?php echo __a('admin.pages.path_label'); ?> <code>?page=<?php echo htmlspecialchars($p_slug); ?></code></span>
                                        
                                        <!-- Sprach-Badges (Klickbar für Direktsprung zur Sprache) -->
                                        <span style="display:inline-flex; align-items:center; gap:4px;">
                                            <span style="font-size:0.75rem; color:var(--text-secondary);"><?php echo __a('admin.pages.languages_label'); ?></span>
                                            <span onclick="editPage(<?php echo htmlspecialchars(json_encode($p), ENT_QUOTES, 'UTF-8'); ?>, '<?php echo $primary_lang; ?>')" style="font-size:0.72rem; font-weight:700; background:rgba(16,185,129,0.15); color:#10b981; padding:2px 8px; border-radius:4px; cursor:pointer;" title="<?php echo htmlspecialchars($supported_langs[$primary_lang]['name']); ?> bearbeiten">
                                                <?php echo $supported_langs[$primary_lang]['flag'] . ' ' . strtoupper($primary_lang); ?>
                                            </span>
                                            <?php foreach ($active_langs as $al): if ($al === $primary_lang) continue; ?>
                                                <?php 
                                                    $has_trans = !empty($p['translations'][$al]['title']) || !empty($p['translations'][$al]['content']) || !empty($p['translations'][$al]['nav_label']); 
                                                ?>
                                                <span onclick="editPage(<?php echo htmlspecialchars(json_encode($p), ENT_QUOTES, 'UTF-8'); ?>, '<?php echo $al; ?>')" style="font-size:0.72rem; font-weight:700; background:<?php echo $has_trans ? 'rgba(16,185,129,0.15)' : 'rgba(255,255,255,0.05)'; ?>; color:<?php echo $has_trans ? '#10b981' : 'var(--text-secondary)'; ?>; padding:2px 8px; border-radius:4px; border:1px solid <?php echo $has_trans ? 'rgba(16,185,129,0.3)' : 'var(--border-color)'; ?>; cursor:pointer;" title="<?php echo $has_trans ? 'Übersetzung für ' . htmlspecialchars($supported_langs[$al]['name']) . ' bearbeiten' : 'Neue Übersetzung für ' . htmlspecialchars($supported_langs[$al]['name']) . ' anlegen'; ?>">
                                                    <?php echo $supported_langs[$al]['flag'] . ' ' . strtoupper($al); ?> <?php echo $has_trans ? '✓' : '+'; ?>
                                                </span>
                                            <?php endforeach; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div style="display:flex; align-items:center; gap:8px;">
                                <a href="<?php echo htmlspecialchars($p_preview_url); ?>" target="_blank" class="btn btn-secondary" style="padding:6px 12px; font-size:0.82rem; text-decoration:none;" title="<?php echo htmlspecialchars(__a('admin.pages.btn_preview')); ?>">
                                    <span class="material-icons" style="font-size:16px;">visibility</span> <?php echo __a('admin.pages.btn_preview'); ?>
                                </a>
                                <button type="button" class="btn btn-secondary" onclick="openRevisionsModal('page', '<?php echo htmlspecialchars($p['id'] ?? '', ENT_QUOTES); ?>', '<?php echo htmlspecialchars($p['title'] ?? '', ENT_QUOTES); ?>')" style="padding:6px 12px; font-size:0.82rem;" title="<?php echo htmlspecialchars(__a('admin.pages.btn_revisions')); ?>">
                                    <span class="material-icons" style="font-size:16px;">history</span> <?php echo __a('admin.pages.btn_revisions'); ?>
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="editPage(<?php echo htmlspecialchars(json_encode($p), ENT_QUOTES, 'UTF-8'); ?>)" style="padding:6px 12px; font-size:0.82rem;">
                                    <span class="material-icons" style="font-size:16px;">edit</span> <?php echo __a('admin.pages.btn_edit'); ?>
                                </button>
                                <form method="POST" action="" style="display:inline;" onsubmit="return confirm(<?php echo htmlspecialchars(json_encode(__a('admin.pages.confirm_delete'))); ?>);">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                    <input type="hidden" name="action" value="delete_page">
                                    <input type="hidden" name="target_tab" value="tab-pages">
                                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($p['id'] ?? ''); ?>">
                                    <button type="submit" class="btn btn-secondary" style="padding:6px 10px; color:#ef4444;" title="<?php echo htmlspecialchars(__a('admin.pages.btn_delete')); ?>">
                                        <span class="material-icons" style="font-size:16px;">delete</span>
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <script>
        const PAGE_ACTIVE_LANGS = <?php echo json_encode($active_langs); ?>;
        const PAGE_PRIMARY_LANG = <?php echo json_encode($primary_lang); ?>;
        const ALL_PAGES_DATA = <?php echo json_encode(array_values($pages)); ?>;
        let CURRENT_ACTIVE_PAGE_LANG = PAGE_PRIMARY_LANG;

        function switchPageLangTab(lang) {
            CURRENT_ACTIVE_PAGE_LANG = lang;
            document.querySelectorAll('.page-lang-panel').forEach(el => el.style.display = 'none');
            const targetPanel = document.getElementById('page-lang-panel-' + lang);
            if (targetPanel) {
                targetPanel.style.display = 'block';
            }

            // Sticky-Pills synchronisieren
            document.querySelectorAll('.sticky-lang-pill').forEach(btn => {
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-outline');
            });
            const activeStickyBtn = document.getElementById('sticky-lang-btn-' + lang);
            if (activeStickyBtn) {
                activeStickyBtn.classList.remove('btn-outline');
                activeStickyBtn.classList.add('btn-primary');
            }

            // Fallback für Standard-Buttons (falls vorhanden)
            document.querySelectorAll('.page-lang-tab-btn').forEach(btn => {
                btn.classList.remove('btn-primary');
                btn.classList.add('btn-outline');
            });
            const activeBtn = document.getElementById('btn-page-lang-' + lang);
            if (activeBtn) {
                activeBtn.classList.remove('btn-outline');
                activeBtn.classList.add('btn-primary');
            }
        }

        function updateStickyTranslationDots() {
            const primTitle = (document.getElementById('page_title') ? document.getElementById('page_title').value.trim() : '');
            const primContent = (document.getElementById('page_content') ? document.getElementById('page_content').value.trim() : '');
            const primDot = document.getElementById('sticky-dot-' + PAGE_PRIMARY_LANG);
            if (primDot) {
                if (primTitle || primContent) {
                    primDot.style.background = '#10b981';
                    primDot.title = <?php echo json_encode(__a('admin.pages.status_dot_ok')); ?>;
                } else {
                    primDot.style.background = '#f59e0b';
                    primDot.title = <?php echo json_encode(__a('admin.pages.status_dot_empty')); ?>;
                }
            }

            PAGE_ACTIVE_LANGS.forEach(lang => {
                if (lang === PAGE_PRIMARY_LANG) return;
                const tTitle = document.getElementById('trans_' + lang + '_title');
                const tContent = document.getElementById('trans_' + lang + '_content');
                const tNav = document.getElementById('trans_' + lang + '_nav_label');
                const hasText = (tTitle && tTitle.value.trim().length > 0) || 
                                (tContent && tContent.value.trim().length > 0) || 
                                (tNav && tNav.value.trim().length > 0);
                const dot = document.getElementById('sticky-dot-' + lang);
                if (dot) {
                    if (hasText) {
                        dot.style.background = '#10b981';
                        dot.title = <?php echo json_encode(__a('admin.pages.status_dot_ok')); ?>;
                    } else {
                        dot.style.background = '#94a3b8';
                        dot.title = <?php echo json_encode(__a('admin.pages.status_dot_empty')); ?>;
                    }
                }
            });
        }

        function onStickyPageSelect(pageId) {
            if (!pageId) {
                openPageEditor();
                return;
            }
            const page = ALL_PAGES_DATA.find(p => String(p.id) === String(pageId));
            if (page) {
                editPage(page, CURRENT_ACTIVE_PAGE_LANG);
            }
        }

        function submitPageFormQuick() {
            const form = document.getElementById('page-form');
            if (form) {
                if (typeof form.reportValidity === 'function' && !form.reportValidity()) {
                    return;
                }
                form.submit();
            }
        }

        function togglePageTypeMode(type) {
            const modBox = document.getElementById('modular-sections-box');
            if (modBox) {
                modBox.style.display = (type === 'modular') ? 'block' : 'none';
            }
        }

        function togglePageScheduledBox(status) {
            const box = document.getElementById('page_scheduled_box');
            if (box) {
                box.style.display = (status === 'scheduled') ? 'block' : 'none';
            }
        }

        function openPageEditor() {
            document.getElementById('page-editor-box').style.display = 'block';
            document.getElementById('page-editor-title').innerHTML = '<span class="material-icons">add_circle</span> ' + <?php echo json_encode(__a('admin.pages.new_page')); ?>;
            document.getElementById('page_form_action').value = 'add_page';
            document.getElementById('page_id').value = '';
            document.getElementById('page_title').value = '';
            document.getElementById('page_slug').value = '';
            document.getElementById('page_type').value = 'content';
            document.getElementById('page_icon').value = 'article';
            updatePageIconPreview('article');
            document.getElementById('page_nav_label').value = '';
            document.getElementById('page_status').value = 'published';
            if (document.getElementById('page_publish_at')) document.getElementById('page_publish_at').value = '';
            if (document.getElementById('page_revision_note')) document.getElementById('page_revision_note').value = '';
            togglePageScheduledBox('published');
            document.getElementById('page_in_nav').checked = false;
            document.getElementById('page_meta_desc').value = '';
            document.getElementById('page_content').value = '';

            document.querySelectorAll('.modular-sec-checkbox').forEach(cb => {
                cb.checked = false;
            });
            togglePageTypeMode('content');

            PAGE_ACTIVE_LANGS.forEach(lang => {
                if (lang === PAGE_PRIMARY_LANG) return;
                const tTitle = document.getElementById('trans_' + lang + '_title');
                const tNav = document.getElementById('trans_' + lang + '_nav_label');
                const tMeta = document.getElementById('trans_' + lang + '_meta_desc');
                const tContent = document.getElementById('trans_' + lang + '_content');
                if (tTitle) tTitle.value = '';
                if (tNav) tNav.value = '';
                if (tMeta) tMeta.value = '';
                if (tContent) tContent.value = '';
            });

            const sel = document.getElementById('sticky_page_selector');
            if (sel) sel.value = '';

            switchPageLangTab(PAGE_PRIMARY_LANG);
            updateStickyTranslationDots();
            document.getElementById('page-submit-btn').innerHTML = '<span class="material-icons" style="font-size:18px;">save</span> ' + <?php echo json_encode(__a('admin.pages.btn_create')); ?>;
            document.getElementById('page_title').focus();
        }

        function closePageEditor() {
            document.getElementById('page-editor-box').style.display = 'none';
        }

        function updatePageIconPreview(val) {
            const prev = document.getElementById('page_icon_preview');
            if (prev) {
                prev.textContent = val && val.trim() ? val.trim() : 'article';
            }
        }

        function editPage(pageData, targetLang = null) {
            document.getElementById('page-editor-box').style.display = 'block';
            document.getElementById('page-editor-title').innerHTML = '<span class="material-icons">edit</span> ' + <?php echo json_encode(__a('admin.pages.edit_page')); ?>;
            document.getElementById('page_form_action').value = 'edit_page';
            document.getElementById('page_id').value = pageData.id || '';
            document.getElementById('page_title').value = pageData.title || '';
            document.getElementById('page_slug').value = pageData.slug || '';
            const pType = pageData.page_type || 'content';
            document.getElementById('page_type').value = pType;
            document.getElementById('page_icon').value = pageData.icon || 'article';
            updatePageIconPreview(pageData.icon || 'article');
            document.getElementById('page_nav_label').value = pageData.nav_label || '';
            const pStatus = pageData.status || 'published';
            document.getElementById('page_status').value = pStatus;
            if (document.getElementById('page_publish_at')) document.getElementById('page_publish_at').value = pageData.publish_at || '';
            if (document.getElementById('page_revision_note')) document.getElementById('page_revision_note').value = '';
            togglePageScheduledBox(pStatus);
            document.getElementById('page_in_nav').checked = !!pageData.in_nav;
            document.getElementById('page_meta_desc').value = pageData.meta_description || '';
            document.getElementById('page_content').value = pageData.content || '';

            const chosenSecs = Array.isArray(pageData.page_sections) ? pageData.page_sections : [];
            document.querySelectorAll('.modular-sec-checkbox').forEach(cb => {
                cb.checked = chosenSecs.includes(cb.value);
            });
            togglePageTypeMode(pType);

            const trans = pageData.translations || {};
            PAGE_ACTIVE_LANGS.forEach(lang => {
                if (lang === PAGE_PRIMARY_LANG) return;
                const langTrans = trans[lang] || {};
                const tTitle = document.getElementById('trans_' + lang + '_title');
                const tNav = document.getElementById('trans_' + lang + '_nav_label');
                const tMeta = document.getElementById('trans_' + lang + '_meta_desc');
                const tContent = document.getElementById('trans_' + lang + '_content');
                if (tTitle) tTitle.value = langTrans.title || '';
                if (tNav) tNav.value = langTrans.nav_label || '';
                if (tMeta) tMeta.value = langTrans.meta_description || '';
                if (tContent) tContent.value = langTrans.content || '';
            });

            const sel = document.getElementById('sticky_page_selector');
            if (sel) sel.value = pageData.id || '';

            const switchLang = targetLang && PAGE_ACTIVE_LANGS.includes(targetLang) ? targetLang : PAGE_PRIMARY_LANG;
            switchPageLangTab(switchLang);
            updateStickyTranslationDots();
            document.getElementById('page-submit-btn').innerHTML = '<span class="material-icons" style="font-size:18px;">save</span> ' + <?php echo json_encode(__a('admin.pages.btn_save')); ?>;
            document.getElementById('page-editor-box').scrollIntoView({ behavior: 'smooth' });
        }

        // Live-Aktualisierung der Statuspunkte bei Eingabe
        document.addEventListener('DOMContentLoaded', function() {
            const watchFields = ['page_title', 'page_content', 'page_nav_label'];
            PAGE_ACTIVE_LANGS.forEach(function(lang) {
                if (lang === PAGE_PRIMARY_LANG) return;
                watchFields.push('trans_' + lang + '_title', 'trans_' + lang + '_content', 'trans_' + lang + '_nav_label');
            });
            watchFields.forEach(function(id) {
                const el = document.getElementById(id);
                if (el) {
                    el.addEventListener('input', updateStickyTranslationDots);
                }
            });
        });

        function autoGeneratePageSlug(title) {
            const slugInput = document.getElementById('page_slug');
            if (document.getElementById('page_form_action').value === 'add_page') {
                const map = {'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss'};
                let s = title.toLowerCase();
                for (let k in map) { s = s.split(k).join(map[k]); }
                s = s.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
                slugInput.value = s;
            }
        }

        function insertPageSnippet(selectElem, type) {
            const val = selectElem.value;
            if (!val) return;

            let target = document.activeElement;
            if (!target || target.tagName !== 'TEXTAREA') {
                const activeLangPanel = document.querySelector('.page-lang-panel:not([style*="display: none"])');
                target = activeLangPanel ? activeLangPanel.querySelector('textarea') : document.getElementById('page_content');
            }
            if (!target) {
                target = document.getElementById('page_content');
            }

            let snippet = '';
            const colorPicker = document.getElementById('picker_box_color');
            const chosenColor = colorPicker ? colorPicker.value : '#e0f2fe';

            if (type === 'heading') {
                switch(val) {
                    case 'left_bar':
                        snippet = '\n<h3 class="heading-left-bar">Überschrift mit Akzentleiste</h3>\n';
                        break;
                    case 'underline':
                        snippet = '\n<h3 class="heading-underline">Überschrift mit Unterstrich</h3>\n';
                        break;
                    case 'eyebrow':
                        snippet = '\n<div class="heading-eyebrow">KATEGORIE / THEMA</div>\n<h2 class="heading-title">Große Hauptüberschrift</h2>\n';
                        break;
                    case 'gradient':
                        snippet = '\n<h2 class="heading-gradient">Farbverlauf-Überschrift</h2>\n';
                        break;
                    case 'icon':
                        snippet = '\n<h3 class="heading-icon"><span class="heading-icon-badge">✨</span> Überschrift mit Icon</h3>\n';
                        break;
                    case 'display':
                        snippet = '\n<h1 class="heading-display">Markanter Display-Titel</h1>\n';
                        break;
                }
            } else if (type === 'box') {
                switch(val) {
                    case 'soft_primary':
                        snippet = '\n<div class="box-soft box-soft-primary">\n  <h4>Titel der Box</h4>\n  <p>Hier steht der beschreibende Text in einem harmonischen Theme-Farbton.</p>\n</div>\n';
                        break;
                    case 'soft_success':
                        snippet = '\n<div class="box-soft box-soft-success">\n  <h4>Erfolgs- &amp; Statusmeldung</h4>\n  <p>Hier steht der Text im frischen Smaragdgrün-Ton.</p>\n</div>\n';
                        break;
                    case 'soft_amber':
                        snippet = '\n<div class="box-soft box-soft-amber">\n  <h4>Wichtiger Hinweis</h4>\n  <p>Hier steht der Informationstext im warmen Bernsteinton.</p>\n</div>\n';
                        break;
                    case 'soft_purple':
                        snippet = '\n<div class="box-soft box-soft-purple">\n  <h4>Kreativ-Bereich &amp; Besonderheiten</h4>\n  <p>Hier steht der Text im inspirierenden Violettton.</p>\n</div>\n';
                        break;
                    case 'gradient':
                        snippet = '\n<div class="box-card box-gradient-primary">\n  <h4>Highlight mit Farbverlauf</h4>\n  <p>Ein besonders auffälliger Block mit dynamischem Verlaufshintergrund.</p>\n</div>\n';
                        break;
                    case 'dark':
                        snippet = '\n<div class="box-card box-dark">\n  <h4>Dunkle Premium-Karte</h4>\n  <p>Exklusiver Slate-Hintergrund für moderne Kontraste.</p>\n</div>\n';
                        break;
                    case 'tintable':
                        snippet = '\n<div class="box-tintable" style="background: ' + chosenColor + ';">\n  <h4>Individuell eingefärbte Box</h4>\n  <p>Passe die Hintergrundfarbe ganz nach Wunsch über das style-Attribut oder den Farbwähler an.</p>\n</div>\n';
                        break;
                }
            } else if (type === 'divider') {
                switch(val) {
                    case 'gradient':
                        snippet = '\n<div class="divider-gradient"></div>\n';
                        break;
                    case 'icon_leaf':
                        snippet = '\n<div class="divider-icon"><span>🌿</span></div>\n';
                        break;
                    case 'icon_star':
                        snippet = '\n<div class="divider-icon"><span>⭐</span></div>\n';
                        break;
                    case 'glow':
                        snippet = '\n<div class="divider-glow"></div>\n';
                        break;
                    case 'dots':
                        snippet = '\n<div class="divider-dots"></div>\n';
                        break;
                    case 'dashed':
                        snippet = '\n<div class="divider-dashed"></div>\n';
                        break;
                    case 'wave':
                        snippet = '\n<div class="divider-wave"></div>\n';
                        break;
                }
            }

            if (snippet && target) {
                const start = target.selectionStart || target.value.length;
                const end = target.selectionEnd || target.value.length;
                const text = target.value;
                target.value = text.substring(0, start) + snippet + text.substring(end);
                target.focus();
                const newPos = start + snippet.length;
                target.setSelectionRange(newPos, newPos);
            }

            selectElem.selectedIndex = 0;
        }
        </script>
