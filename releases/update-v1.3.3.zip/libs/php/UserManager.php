<?php
/**
 * ============================================================================
 * WeaveCMS - Mehrbenutzersystem & Rechteverwaltung (UserManager) - Phase 10
 * ============================================================================
 * Verwaltet:
 * - Benutzerkonten, Bcrypt-Passwörter und Rollen (Admin, Moderator, Redakteur)
 * - Rollenbasierte Zugriffskontrolle (RBAC) für Tabs und POST-Aktionen
 * - Automatische Migration / Seeding des initialen Superadmins
 * - Sitzungszuordnung des aktuell angemeldeten Benutzers
 * ============================================================================
 */

class UserManager {

    public const ROLE_ADMIN = 'admin';
    public const ROLE_MODERATOR = 'moderator';
    public const ROLE_EDITOR = 'editor';

    /**
     * Liefert alle verfügbaren Systemrollen und deren Bezeichnungen.
     * @return array
     */
    public static function getRoles(): array {
        return [
            self::ROLE_ADMIN     => [
                'name'        => 'Administrator',
                'description' => 'Vollzugriff auf alle Bereiche (Dashboard, Inhalte, Benutzer, Design, SEO, Sicherheit & Backups).'
            ],
            self::ROLE_MODERATOR => [
                'name'        => 'Moderator',
                'description' => 'Redaktionelle Leitung (Dashboard, Inhalte, Galerie, Blog, Seiten, Kontaktpostfach).'
            ],
            self::ROLE_EDITOR    => [
                'name'        => 'Redakteur',
                'description' => 'Reine Inhaltspflege (Dashboard, Texte, Blogbeiträge, Galeriebilder).'
            ]
        ];
    }

    /**
     * Stellt sicher, dass das Datenmodell initialisiert ist und mindestens ein Superadmin existiert.
     * @param array &$data
     * @return array Benutzer-Array
     */
    public static function ensureInitialized(array &$data): array {
        if (!isset($data['users']) || !is_array($data['users']) || empty($data['users'])) {
            $pwHash = $data['settings']['admin_password_hash'] ?? null;
            if (empty($pwHash)) {
                $defaultPw = defined('DEFAULT_ADMIN_PASSWORD') ? DEFAULT_ADMIN_PASSWORD : bin2hex(random_bytes(8));
                $pwHash = password_hash($defaultPw, PASSWORD_DEFAULT);
            }

            $pinHash = $data['settings']['admin_pin_hash'] ?? null;
            if (empty($pinHash)) {
                $defaultPin = defined('DEFAULT_ADMIN_PIN') ? DEFAULT_ADMIN_PIN : (string)random_int(1000, 9999);
                $pinHash = password_hash($defaultPin, PASSWORD_DEFAULT);
            }

            $adminUser = !empty($data['settings']['admin_username']) ? $data['settings']['admin_username'] : 'admin';
            $adminEmail = !empty($data['texts']['contact_email']) ? $data['texts']['contact_email'] : 'admin@weavecms.local';

            $data['users'] = [
                [
                    'id'            => 'usr_superadmin',
                    'username'      => $adminUser,
                    'email'         => $adminEmail,
                    'password_hash' => $pwHash,
                    'pin_hash'      => $pinHash,
                    'role'          => self::ROLE_ADMIN,
                    'admin_lang'    => 'de',
                    'active'        => true,
                    'created_at'    => date('Y-m-d H:i:s'),
                    'last_login'    => date('Y-m-d H:i:s')
                ]
            ];
        } else {
            // Sicherstellen, dass alle bestehenden Benutzer ein admin_lang-Feld besitzen
            foreach ($data['users'] as &$exUser) {
                if (empty($exUser['admin_lang']) || !in_array($exUser['admin_lang'], ['de', 'en'], true)) {
                    $exUser['admin_lang'] = 'de';
                }
            }
        }

        return $data['users'];
    }

    /**
     * Gibt alle registrierten Benutzer zurück.
     * @param array $data
     * @return array
     */
    public static function getUsers(array $data): array {
        return $data['users'] ?? [];
    }

    /**
     * Sucht einen Benutzer nach ID.
     * @param string $id
     * @param array $data
     * @return array|null
     */
    public static function getUserById(string $id, array $data): ?array {
        foreach (self::getUsers($data) as $user) {
            if ($user['id'] === $id) {
                return $user;
            }
        }
        return null;
    }

    /**
     * Sucht einen Benutzer nach Benutzername oder E-Mail.
     * @param string $identifier
     * @param array $data
     * @return array|null
     */
    public static function getUserByIdentifier(string $identifier, array $data): ?array {
        $identLower = strtolower(trim($identifier));
        foreach (self::getUsers($data) as $user) {
            if (strtolower($user['username']) === $identLower || strtolower($user['email'] ?? '') === $identLower) {
                return $user;
            }
        }
        return null;
    }

    /**
     * Liefert den aktuell angemeldeten Benutzer aus der Sitzung.
     * @param array|null $data
     * @return array
     */
    public static function getCurrentUser(?array $data = null): array {
        AuthManager::initSession();
        $userId = $_SESSION['admin_user_id'] ?? null;

        if ($data && $userId) {
            $user = self::getUserById($userId, $data);
            if ($user) {
                return $user;
            }
        }

        // Fallback für Superadmin aus bestehender Session
        $fallbackUser = !empty($data['settings']['admin_username']) ? $data['settings']['admin_username'] : 'admin';
        $fallbackEmail = !empty($data['texts']['contact_email']) ? $data['texts']['contact_email'] : 'admin@weavecms.local';
        return [
            'id'       => $userId ?? 'usr_superadmin',
            'username' => $_SESSION['admin_username'] ?? $fallbackUser,
            'role'     => $_SESSION['admin_role'] ?? self::ROLE_ADMIN,
            'email'    => $fallbackEmail,
            'active'   => true
        ];
    }

    /**
     * Speichert den angemeldeten Benutzer in der aktiven Sitzung.
     * @param array $user
     * @return void
     */
    public static function setCurrentUser(array $user): void {
        AuthManager::initSession();
        $_SESSION['admin_user_id'] = $user['id'];
        $_SESSION['admin_username'] = $user['username'];
        $_SESSION['admin_role'] = $user['role'];
        if (!empty($user['admin_lang']) && in_array($user['admin_lang'], ['de', 'en'], true)) {
            $_SESSION[LanguageManager::ADMIN_COOKIE_NAME] = $user['admin_lang'];
            if (!headers_sent()) {
                setcookie(LanguageManager::ADMIN_COOKIE_NAME, $user['admin_lang'], time() + 86400 * 365, '/');
            }
        }
    }

    /**
     * Prüft Benutzer-Zugangsdaten (Benutzername/E-Mail, Passwort und optional PIN).
     * @param string $identifier
     * @param string $password
     * @param string $pin
     * @param array $data
     * @return array|null Gibt Benutzerarray bei Erfolg oder null bei Fehlschlag zurück
     */
    public static function authenticate(string $identifier, string $password, string $pin, array &$data): ?array {
        self::ensureInitialized($data);

        // Falls kein Identifier übergeben wurde, Fallback auf 'admin'
        $ident = !empty(trim($identifier)) ? trim($identifier) : 'admin';
        $user = self::getUserByIdentifier($ident, $data);

        if (!$user) {
            return null;
        }

        if (empty($user['active'])) {
            return null; // Deaktivierter Benutzer
        }

        // Passwort verifizieren
        $pwOk = false;
        if (!empty($user['password_hash']) && password_verify($password, $user['password_hash'])) {
            $pwOk = true;
        } elseif (defined('DEFAULT_ADMIN_PASSWORD') && DEFAULT_ADMIN_PASSWORD !== '' && $password === DEFAULT_ADMIN_PASSWORD) {
            $pwOk = true;
        }

        if (!$pwOk) {
            return null;
        }

        // PIN verifizieren (nur Administratoren und Moderatoren benötigen standardmäßig die PIN)
        if ($user['role'] === self::ROLE_ADMIN) {
            $pinOk = false;
            if (!empty($user['pin_hash']) && password_verify($pin, $user['pin_hash'])) {
                $pinOk = true;
            } elseif (defined('DEFAULT_ADMIN_PIN') && DEFAULT_ADMIN_PIN !== '' && $pin === DEFAULT_ADMIN_PIN) {
                $pinOk = true;
            }

            if (!$pinOk) {
                return null;
            }
        }

        // Login-Zeitstempel aktualisieren
        foreach ($data['users'] as &$u) {
            if ($u['id'] === $user['id']) {
                $u['last_login'] = date('Y-m-d H:i:s');
                break;
            }
        }

        return $user;
    }

    /**
     * Prüft, ob eine Rolle Zugriff auf einen Admin-Reiter hat.
     * @param string $tabId
     * @param string|null $role
     * @return bool
     */
    public static function canAccessTab(string $tabId, ?string $role = null): bool {
        $curRole = $role ?? ($_SESSION['admin_role'] ?? self::ROLE_ADMIN);

        // Superadmin darf alles
        if ($curRole === self::ROLE_ADMIN) {
            return true;
        }

        // Dashboard, Inhalte (inkl. aller Content-Untertabs) und Mediathek für alle angemeldeten Rollen
        $contentTabs = ['tab-dashboard', 'tab-content', 'tab-media', 'tab-texts', 'tab-pages', 'tab-blog', 'tab-faqs', 'tab-team', 'tab-pricing', 'tab-downloads', 'tab-impressum', 'tab-gallery', 'tab-past', 'tab-courses'];
        if (in_array($tabId, $contentTabs, true)) {
            return true;
        }

        // Moderator darf zusätzlich Kontaktanfragen einsehen
        if ($curRole === self::ROLE_MODERATOR) {
            if ($tabId === 'tab-inbox') {
                return true;
            }
        }

        // Redakteure und Moderatoren haben keinen Zugriff auf Benutzer, Design, SEO oder System
        return false;
    }

    /**
     * Prüft serverseitig, ob eine POST-Aktion mit der aktuellen Rolle ausgeführt werden darf (Phase 10.5).
     * @param string $action
     * @param string|null $role
     * @return bool
     */
    public static function canExecuteAction(string $action, ?string $role = null): bool {
        $curRole = $role ?? ($_SESSION['admin_role'] ?? self::ROLE_ADMIN);

        if ($curRole === self::ROLE_ADMIN) {
            return true;
        }

        // Reine Content-Aktionen (Redakteur & Moderator erlaubt)
        $editorialActions = [
            'update_texts', 'update_impressum', 'add_gallery', 'edit_gallery', 'delete_gallery', 'reorder_gallery',
            'add_course', 'delete_course', 'add_past_course', 'delete_past_course',
            'add_custom_page', 'update_custom_page', 'delete_custom_page',
            'add_faq', 'update_faq', 'delete_faq',
            'add_team_member', 'update_team_member', 'delete_team_member',
            'add_download', 'edit_download', 'update_download', 'delete_download', 'reset_download_counter',
            'add_pricing_plan', 'update_pricing_plan', 'delete_pricing_plan',
            'add_blog_post', 'update_blog_post', 'delete_blog_post',
            'upload_media', 'delete_media', 'update_media_meta',
            'update_profile_password', 'save_quickactions', 'reset_quickactions',
            'set_user_language'
        ];

        if (in_array($action, $editorialActions, true)) {
            return true;
        }

        // Postfach-Aktionen (nur Moderator und Admin erlaubt)
        if ($curRole === self::ROLE_MODERATOR) {
            if ($action === 'inbox_set_status' || $action === 'inbox_delete') {
                return true;
            }
        }

        // Alle anderen System-, Design-, Backup-, Benutzer- und Speicheraktionen sind gesperrt!
        return false;
    }

    /**
     * Legt einen neuen Benutzer an.
     * @param array &$data
     * @param string $username
     * @param string $email
     * @param string $password
     * @param string $role
     * @param string|null $pin
     * @param string $adminLang
     * @return array ['success' => bool, 'message' => string]
     */
    public static function createUser(array &$data, string $username, string $email, string $password, string $role = self::ROLE_EDITOR, ?string $pin = null, string $adminLang = 'de'): array {
        self::ensureInitialized($data);

        $cleanUsername = trim($username);
        $cleanEmail = trim($email);

        if (empty($cleanUsername) || strlen($cleanUsername) < 3) {
            return ['success' => false, 'message' => 'Der Benutzername muss mindestens 3 Zeichen lang sein.'];
        }

        if (self::getUserByIdentifier($cleanUsername, $data) !== null) {
            return ['success' => false, 'message' => 'Dieser Benutzername ist bereits vergeben.'];
        }

        if (!empty($cleanEmail) && !filter_var($cleanEmail, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'Bitte gib eine gültige E-Mail-Adresse an.'];
        }

        if (strlen($password) < 6) {
            return ['success' => false, 'message' => 'Das Passwort muss mindestens 6 Zeichen lang sein.'];
        }

        $validRoles = [self::ROLE_ADMIN, self::ROLE_MODERATOR, self::ROLE_EDITOR];
        if (!in_array($role, $validRoles, true)) {
            $role = self::ROLE_EDITOR;
        }

        $cleanLang = strtolower(trim($adminLang));
        if (!in_array($cleanLang, ['de', 'en'], true)) {
            $cleanLang = 'de';
        }

        $newUser = [
            'id'            => 'usr_' . bin2hex(random_bytes(6)),
            'username'      => $cleanUsername,
            'email'         => $cleanEmail,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'pin_hash'      => (!empty($pin)) ? password_hash($pin, PASSWORD_DEFAULT) : null,
            'role'          => $role,
            'admin_lang'    => $cleanLang,
            'active'        => true,
            'created_at'    => date('Y-m-d H:i:s'),
            'last_login'    => null
        ];

        $data['users'][] = $newUser;
        SecurityManager::logEvent('USER_CREATED', "Neuer Benutzer angelegt: {$cleanUsername} (Rolle: {$role}, Sprache: {$cleanLang})", 'INFO');

        return ['success' => true, 'message' => "Benutzer '{$cleanUsername}' erfolgreich angelegt!"];
    }

    /**
     * Aktualisiert einen bestehenden Benutzer.
     * @param array &$data
     * @param string $id
     * @param array $fields
     * @return array
     */
    public static function updateUser(array &$data, string $id, array $fields): array {
        self::ensureInitialized($data);

        foreach ($data['users'] as &$user) {
            if ($user['id'] === $id) {
                if (isset($fields['email'])) {
                    $user['email'] = trim($fields['email']);
                }
                if (isset($fields['role']) && in_array($fields['role'], [self::ROLE_ADMIN, self::ROLE_MODERATOR, self::ROLE_EDITOR], true)) {
                    // Verhindern, dass der letzte Admin herabgestuft wird
                    if ($user['role'] === self::ROLE_ADMIN && $fields['role'] !== self::ROLE_ADMIN && self::countActiveAdmins($data) <= 1) {
                        return ['success' => false, 'message' => 'Der letzte Administrator kann nicht herabgestuft werden.'];
                    }
                    $user['role'] = $fields['role'];
                }
                if (isset($fields['active'])) {
                    $activeVal = (bool)$fields['active'];
                    if (!$activeVal && $user['role'] === self::ROLE_ADMIN && self::countActiveAdmins($data) <= 1) {
                        return ['success' => false, 'message' => 'Der letzte Administrator kann nicht deaktiviert werden.'];
                    }
                    $user['active'] = $activeVal;
                }
                if (isset($fields['admin_lang'])) {
                    $lCode = strtolower(trim($fields['admin_lang']));
                    if (in_array($lCode, ['de', 'en'], true)) {
                        $user['admin_lang'] = $lCode;
                        if (!empty($_SESSION['admin_user_id']) && $_SESSION['admin_user_id'] === $id) {
                            $_SESSION[LanguageManager::ADMIN_COOKIE_NAME] = $lCode;
                            if (!headers_sent()) {
                                setcookie(LanguageManager::ADMIN_COOKIE_NAME, $lCode, time() + 86400 * 365, '/');
                            }
                        }
                    }
                }
                if (!empty($fields['new_password'])) {
                    $user['password_hash'] = password_hash($fields['new_password'], PASSWORD_DEFAULT);
                }
                if (!empty($fields['new_pin'])) {
                    $user['pin_hash'] = password_hash($fields['new_pin'], PASSWORD_DEFAULT);
                }
                if (isset($fields['two_factor_enabled'])) {
                    $user['two_factor_enabled'] = (bool)$fields['two_factor_enabled'];
                }
                if (isset($fields['two_factor_secret'])) {
                    $user['two_factor_secret'] = trim($fields['two_factor_secret']);
                }
                if (isset($fields['two_factor_backup_codes']) && is_array($fields['two_factor_backup_codes'])) {
                    $user['two_factor_backup_codes'] = $fields['two_factor_backup_codes'];
                }
                if (!empty($fields['reset_2fa'])) {
                    $user['two_factor_enabled'] = false;
                    $user['two_factor_secret'] = null;
                    $user['two_factor_backup_codes'] = [];
                }

                SecurityManager::logEvent('USER_UPDATED', "Benutzer aktualisiert: {$user['username']}", 'INFO');
                return ['success' => true, 'message' => "Benutzer '{$user['username']}' erfolgreich aktualisiert!"];
            }
        }

        return ['success' => false, 'message' => 'Benutzer nicht gefunden.'];
    }

    /**
     * Aktualisiert die bevorzugte Backend-Sprache eines Benutzers.
     * @param array &$data
     * @param string $userId
     * @param string $lang
     * @return bool
     */
    public static function updateUserLanguage(array &$data, string $userId, string $lang): bool {
        $res = self::updateUser($data, $userId, ['admin_lang' => $lang]);
        return !empty($res['success']);
    }

    /**
     * Löscht einen Benutzer (letzter Administrator geschützt).
     * @param array &$data
     * @param string $id
     * @return array
     */
    public static function deleteUser(array &$data, string $id): array {
        self::ensureInitialized($data);

        $currentUser = self::getCurrentUser($data);
        if ($currentUser['id'] === $id) {
            return ['success' => false, 'message' => 'Du kannst dein eigenes aktuell angemeldetes Konto nicht löschen.'];
        }

        $targetUser = self::getUserById($id, $data);
        if (!$targetUser) {
            return ['success' => false, 'message' => 'Benutzer nicht gefunden.'];
        }

        if ($targetUser['role'] === self::ROLE_ADMIN && self::countActiveAdmins($data) <= 1) {
            return ['success' => false, 'message' => 'Der letzte Administrator kann nicht gelöscht werden.'];
        }

        $filtered = [];
        foreach ($data['users'] as $u) {
            if ($u['id'] !== $id) {
                $filtered[] = $u;
            }
        }
        $data['users'] = $filtered;

        SecurityManager::logEvent('USER_DELETED', "Benutzer gelöscht: {$targetUser['username']}", 'WARNING');
        return ['success' => true, 'message' => "Benutzer '{$targetUser['username']}' wurde gelöscht."];
    }

    /**
     * Zählt die Anzahl aktiver Administratoren.
     * @param array $data
     * @return int
     */
    public static function countActiveAdmins(array $data): int {
        $count = 0;
        foreach (self::getUsers($data) as $u) {
            if ($u['role'] === self::ROLE_ADMIN && !empty($u['active'])) {
                $count++;
            }
        }
        return $count;
    }

    /**
     * Erzeugt ein farbiges Rollen-Badge für die Benutzeroberfläche.
     * @param string $role
     * @return string HTML-Code
     */
    public static function getRoleBadge(string $role): string {
        switch ($role) {
            case self::ROLE_ADMIN:
                return '<span style="background:rgba(239,68,68,0.12); color:#ef4444; border:1px solid rgba(239,68,68,0.3); border-radius:12px; padding:3px 10px; font-size:0.75rem; font-weight:700; display:inline-flex; align-items:center; gap:4px;"><span class="material-icons" style="font-size:14px;">admin_panel_settings</span> Administrator</span>';
            case self::ROLE_MODERATOR:
                return '<span style="background:rgba(217,119,6,0.12); color:#d97706; border:1px solid rgba(217,119,6,0.3); border-radius:12px; padding:3px 10px; font-size:0.75rem; font-weight:700; display:inline-flex; align-items:center; gap:4px;"><span class="material-icons" style="font-size:14px;">verified</span> Moderator</span>';
            case self::ROLE_EDITOR:
            default:
                return '<span style="background:rgba(16,185,129,0.12); color:#10b981; border:1px solid rgba(16,185,129,0.3); border-radius:12px; padding:3px 10px; font-size:0.75rem; font-weight:700; display:inline-flex; align-items:center; gap:4px;"><span class="material-icons" style="font-size:14px;">edit_note</span> Redakteur</span>';
        }
    }
}
