<?php
/**
 * ============================================================================
 * ARCHITEKTUR- & DESIGN-GOVERNANCE (STRIKTE REGEL):
 * KEIN MENÜ (WEDER IM FRONTEND NOCH IM BACKEND) DARF OHNE VORHERIGE
 * AUSDRÜCKLICHE ZUSTIMMUNG DES BENUTZERS GEÄNDERT, VERSCHOBEN ODER UMPLATZIERT WERDEN!
 * Dies gilt im Backend insbesondere für:
 * - Admin-Header & Abmelde-Menü
 * - Reiter-Navigation (.admin-nav) inklusive aller Reiter, Benennungen und Reihenfolgen
 * ============================================================================
 * 
 * WeaveCMS – Administration Hauptmodul
 * 
 * Orchestriert Authentifizierung (AuthManager), Aktions-Dispatching (AdminController)
 * und das Rendern der modularen Backend-Views.
 *
 * @package WeaveCMS\Admin
 */

require_once '../config.php';

// 1. Zentrale Datenbasis (data.json oder SQL) laden
$data_file = '../data.json';
$data = load_data($data_file, [
    'settings' => [
        'upload_dir' => 'images/uploads',
        'admin_password_hash' => '',
        'admin_pin_hash' => ''
    ],
    'texts' => [],
    'gallery' => [],
    'courses' => [],
    'past_courses' => []
]);

// Benutzer-Datenmodell initialisieren (Superadmin-Seeding bei Bedarf)
UserManager::ensureInitialized($data);

// Aktive Plugins für Admin-Kontext initialisieren (Phase 13)
PluginManager::loadActivePlugins($data, 'admin');

// 2. Abmeldung (Logout) verarbeiten
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    AuthManager::logout();
    header('Location: ./');
    exit;
}

// 3. Login-Verifikation bei Formularübermittlung
$login_error = '';
if (!empty($_SESSION['login_notice'])) {
    $login_error = $_SESSION['login_notice'];
    unset($_SESSION['login_notice']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $submitted_csrf = $_POST['csrf_token'] ?? '';
    if (!AuthManager::verifyCsrfToken($submitted_csrf)) {
        $login_error = 'Sicherheitswarnung (CSRF): Das Formular-Token ist abgelaufen. Bitte versuche es erneut.';
    } elseif (SecurityManager::isRateLimited('admin_login')) {
        $rem = SecurityManager::getLockoutRemaining('admin_login');
        $mins = max(1, ceil($rem / 60));
        $login_error = "Zu viele Fehlversuche! Der Zugang ist für {$mins} Minute(n) gesperrt ({$rem}s verbleibend).";
    } else {
        $username = trim($_POST['username'] ?? 'admin');
        $password = $_POST['password'] ?? '';
        $pin = $_POST['pin'] ?? '';
        if (AuthManager::login($password, $pin, $data, $username)) {
            save_data($data_file, $data);
            header('Location: ./');
            exit;
        } else {
            if (SecurityManager::isRateLimited('admin_login')) {
                $rem = SecurityManager::getLockoutRemaining('admin_login');
                $mins = max(1, ceil($rem / 60));
                $login_error = "Zu viele Fehlversuche! Der Zugang wurde für {$mins} Minute(n) gesperrt.";
            } else {
                $login_error = 'Ungültiges Passwort oder PIN-Code. Bitte versuche es erneut.';
            }
        }
    }
}

// 4. Authentifizierungs-Check
if (!AuthManager::isLoggedIn($data)) {
    require __DIR__ . '/views/login.php';
    exit;
}

// 5. Download von Backups verarbeiten (nur autorisiert)
if (isset($_GET['action']) && $_GET['action'] === 'download_backup') {
    $file = $_GET['file'] ?? '';
    BackupManager::downloadBackup($file);
    exit;
}

// 6. AJAX Action: test_db_migration (Live-Prüfung der MySQL-Verbindung im Adminbereich)
if (isset($_GET['action']) && $_GET['action'] === 'test_db_migration') {
    header('Content-Type: application/json');
    $res = StorageManager::testDbConnection([
        'host' => $_POST['host'] ?? '127.0.0.1',
        'port' => (int)($_POST['port'] ?? 3306),
        'database' => $_POST['database'] ?? '',
        'username' => $_POST['username'] ?? 'root',
        'password' => $_POST['password'] ?? '',
        'create_db' => !empty($_POST['create_db'])
    ]);
    echo json_encode($res);
    exit;
}

// 7. CSRF-Token für Sitzung generieren oder abrufen
$csrf_token = AuthManager::getCsrfToken();

// 8. Eingehende POST-Aktionen über AdminController verarbeiten
$controllerResult = AdminController::handlePost($data_file, $data, $csrf_token);
$success_msg = $controllerResult['success_msg'];
$error_msg = $controllerResult['error_msg'];
$active_tab = $controllerResult['active_tab'];
if ($_SERVER['REQUEST_METHOD'] !== 'POST' && !empty($_GET['tab'])) {
    $active_tab = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)$_GET['tab']);
}

// 9. Galerie-Elemente im Arbeitsspeicher nach sort_order aufsteigend sortieren
usort($data['gallery'], function($a, $b) {
    return ($a['sort_order'] ?? 0) <=> ($b['sort_order'] ?? 0);
});

// 10. Basis-URL für dynamische Einladungslinks ermitteln (Protokoll + Host + Pfad)
$proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base_path = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
$site_url = $proto . '://' . $host . $base_path . '/';

// 11. Admin-Header Logo vorbereiten
$admin_logo_motif = $data['settings']['hero_logo_motif'] ?? 'paw_beach';
$admin_logo_color = $data['settings']['hero_logo_color'] ?? '#d97706';
$admin_logo_pos = $data['settings']['logo_position'] ?? 'header_before';
$admin_paw = LogoRenderer::render($admin_logo_motif, $admin_logo_color, '1.2em', 'header-paw-logo');

// 12. Galerie-Kategorien & Zähler für Admin vorbereiten
$admin_categories = $data['categories'] ?? ['Korbwaren', 'Gartendeko', 'Sichtschutz', 'Sonstiges'];
$cat_counts = [];
foreach ($admin_categories as $c) {
    $cat_counts[$c] = 0;
}
foreach ($data['gallery'] as $item) {
    $cat = $item['category'] ?? '';
    if (isset($cat_counts[$cat])) {
        $cat_counts[$cat]++;
    } else {
        $cat_counts[$cat] = ($cat_counts[$cat] ?? 0) + 1;
    }
}

// 13. SEO- & Metadaten für Admin vorbereiten
$cur_seo = $data['seo'] ?? [];
$cur_meta_title = $cur_seo['meta_title'] ?? '';
$cur_meta_desc = $cur_seo['meta_description'] ?? '';
$cur_meta_keywords = $cur_seo['meta_keywords'] ?? '';
$cur_robots = $cur_seo['robots'] ?? 'index, follow';
$cur_canonical = $cur_seo['canonical_url'] ?? '';
$cur_og_image = $cur_seo['og_image'] ?? '';

// 14. Postfach- & Dashboard-Daten vorbereiten
$inbox_entries = ContactInbox::all();
$inbox_new_count = ContactInbox::countNew();
$inbox_total_count = count($inbox_entries);

$dashboard_stats = StatsManager::getDashboardSummary();
$cur_user = UserManager::getCurrentUser($data);
$all_users = UserManager::getUsers($data);
$storage_details = StorageManager::getDriverDetails();

// Phase 12: Update-Prüfung für CMS-Kern und installierte Plugins
$core_update_info = class_exists('UpdateManager') ? UpdateManager::checkCoreUpdate(!empty($_GET['check_updates'])) : ['update_available' => false];
$all_installed_plugins = class_exists('PluginManager') ? PluginManager::getAllPlugins($data) : [];
$plugin_updates = class_exists('UpdateManager') ? UpdateManager::checkPluginUpdates($all_installed_plugins, !empty($_GET['check_updates'])) : [];

$recent_security_logs = [];
$logPath = dirname(__DIR__) . '/logs/security.log';
if (file_exists($logPath)) {
    $logLines = array_filter(array_map('trim', file($logPath)));
    $lastLines = array_slice($logLines, -5);
    foreach (array_reverse($lastLines) as $line) {
        if (preg_match('~^\[(.*?)\] \[(.*?)\] \[IP: (.*?)\] \[(.*?)\] (.*?)(?: \| UA: .*)?$~', $line, $m)) {
            $recent_security_logs[] = [
                'time'    => date('H:i, d.m.', strtotime($m[1])),
                'level'   => $m[2],
                'ip'      => $m[3],
                'type'    => $m[4],
                'message' => $m[5]
            ];
        }
    }
}

// 15. Modulare Admin-Views rendern (mit rollenbasierten Zugriffsgrenzen)
require __DIR__ . '/views/header.php';
require __DIR__ . '/views/nav.php';

// Dashboard ist die neue Default-Startseite (Phase 10)
require __DIR__ . '/views/tab_dashboard.php';

// Inhalts-Tabs (für alle angemeldeten Rollen)
if (UserManager::canAccessTab('tab-content', $cur_user['role'])) {
    require __DIR__ . '/views/tab_texts.php';
    require __DIR__ . '/views/tab_pages.php';
    require __DIR__ . '/views/tab_blog.php';
    require __DIR__ . '/views/tab_faqs.php';
    require __DIR__ . '/views/tab_team.php';
    require __DIR__ . '/views/tab_downloads.php';
    require __DIR__ . '/views/tab_pricing.php';
    require __DIR__ . '/views/tab_impressum.php';
    require __DIR__ . '/views/tab_gallery.php';
    require __DIR__ . '/views/tab_past.php';
    require __DIR__ . '/views/tab_courses.php';
}

// Postfach (für Moderator und Administrator)
if (UserManager::canAccessTab('tab-inbox', $cur_user['role'])) {
    require __DIR__ . '/views/tab_inbox.php';
}

// System, Benutzer, Design & SEO (nur für Administratoren)
if ($cur_user['role'] === UserManager::ROLE_ADMIN) {
    require __DIR__ . '/views/tab_users.php';
    require __DIR__ . '/views/tab_display.php';
    require __DIR__ . '/views/tab_design.php';
    require __DIR__ . '/views/tab_seo.php';
    require __DIR__ . '/views/tab_security.php';
    require __DIR__ . '/views/tab_plugins.php';
}

require __DIR__ . '/views/modals.php';
require __DIR__ . '/views/footer.php';
